#!/usr/bin/env python3
"""Download the outdoor weather and solar radiation used by the package (needs internet).

Needs: pandas, meteostat (pip install meteostat). Writes two files to --out-dir:
  weather_bangkok_5min.csv          outdoor temperature and humidity, Bangkok time, 5 min
  solar_bangkok_2018_2019_5min.csv  solar radiation (modeled), Bangkok time, 5 min

Sources: Meteostat station 48455 (hourly, CC BY-NC 4.0, may contain model-filled hours) and
Open-Meteo Historical Weather API (ERA5 reanalysis, attribution required). Values can change if the
providers update their data; the copies in external/ are the ones used for the published files.
"""
import argparse
import json
import urllib.request
from datetime import datetime
from pathlib import Path

import pandas as pd

PERIODS = [(datetime(2018, 6, 30), datetime(2018, 9, 15, 23, 59)),
           (datetime(2019, 3, 5), datetime(2019, 10, 23, 23, 59))]


def weather(start, end):
    import meteostat as ms
    ts = ms.hourly(ms.Station(id="48455"), start, end)
    w = ts.fetch()[["temp", "rhum"]].astype(float)
    w.index = pd.DatetimeIndex(w.index).tz_localize(None) + pd.Timedelta(hours=7)   # source is UTC
    w5 = w.resample("5min").interpolate("time")
    w5.columns = ["outdoor_temp_c", "outdoor_rh_pct"]
    return w5


def solar(start, end):
    url = ("https://archive-api.open-meteo.com/v1/archive?latitude=13.73&longitude=100.56"
           f"&start_date={start:%Y-%m-%d}&end_date={end:%Y-%m-%d}"
           "&hourly=shortwave_radiation,direct_radiation,diffuse_radiation&timezone=Asia%2FBangkok")
    with urllib.request.urlopen(url, timeout=60) as r:
        h = json.load(r)["hourly"]
    s = pd.DataFrame({
        "time": pd.to_datetime(h["time"]) - pd.Timedelta(minutes=30),   # value = mean of the preceding hour
        "solar_ghi_wm2": h["shortwave_radiation"],
        "solar_direct_wm2": h["direct_radiation"],
        "solar_diffuse_wm2": h["diffuse_radiation"]}).set_index("time")
    return s.resample("5min").interpolate("time")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out-dir", default="external")
    a = ap.parse_args()
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    pd.concat([weather(s, e) for s, e in PERIODS]).to_csv(out / "weather_bangkok_5min.csv", index_label="timestamp")
    pd.concat([solar(s, e) for s, e in PERIODS]).to_csv(out / "solar_bangkok_2018_2019_5min.csv", index_label="timestamp")
    print("saved to", out)
