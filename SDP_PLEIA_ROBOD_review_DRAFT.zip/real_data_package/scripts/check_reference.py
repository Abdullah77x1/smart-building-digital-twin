#!/usr/bin/env python3
"""Re-run the reference forecast and lunch test and compare with the frozen results in reference_run/.

Checks (all must pass):
  1. Checksums of data, external inputs and scripts match reference_run/checksums_sha256.txt.
  2. The experiment settings (the "setup" block) are identical to the frozen ones.
  3. Every number is finite (NaN and inf are rejected); the sets of results are identical (no missing or extra keys).
  4. Example counts are identical; errors agree within a tolerance: 1e-6 when the software versions equal
     reference_run/environment.txt, 0.02 (with a warning) when they differ.
The reserved zones (Z1, Z2, Z5) are never run here.

Example (from the package folder):  python scripts/check_reference.py      |  python scripts/check_reference.py --selftest
"""
import hashlib
import json
import math
import platform
import subprocess
import sys
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
STRICT_TOL, RELAXED_TOL = 1e-6, 0.02


def flat(d, prefix=""):
    for k, v in d.items():
        if isinstance(v, dict):
            yield from flat(v, f"{prefix}{k}/")
        else:
            yield f"{prefix}{k}", v


def compare(ref, new, tol):
    """Return the list of problems; empty means the results agree."""
    r, n = dict(flat(ref)), dict(flat(new))
    problems = []
    for k in sorted(set(r) | set(n)):
        if k not in r:
            problems.append(f"{k}: extra result in the new run")
        elif k not in n:
            problems.append(f"{k}: missing in the new run")
        else:
            a, b = r[k], n[k]
            exact = k.startswith("setup/") or k.endswith("/n") or isinstance(a, (str, bool)) or isinstance(b, (str, bool))
            if exact:
                if a != b:
                    problems.append(f"{k}: {a!r} -> {b!r}")
            elif not (isinstance(a, (int, float)) and isinstance(b, (int, float)) and math.isfinite(a) and math.isfinite(b)):
                problems.append(f"{k}: non-finite or non-numeric value ({a!r}, {b!r})")
            elif abs(a - b) > tol:
                problems.append(f"{k}: {a:.6g} -> {b:.6g}")
    return problems


def check_checksums():
    bad = []
    for line in (root / "reference_run/checksums_sha256.txt").read_text().splitlines():
        digest, name = line.split("  ", 1)
        f = root / name
        if not f.exists():
            bad.append(f"{name}: missing")
        elif hashlib.sha256(f.read_bytes()).hexdigest() != digest:
            bad.append(f"{name}: changed")
    return bad


def versions():
    import numpy, pandas, sklearn
    return {"python": platform.python_version(), "pandas": pandas.__version__, "numpy": numpy.__version__,
            "scikit-learn": sklearn.__version__}


def frozen_versions():
    out = {}
    for line in (root / "reference_run/environment.txt").read_text().splitlines():
        k, _, v = line.partition(" ")
        out[k] = v
    return {k: out.get(k) for k in ("python", "pandas", "numpy", "scikit-learn")}


def selftest():
    base = {"setup": {"seed": 42, "version": "v2"}, "set": {"indoor": {"model": {"mae": 0.13, "n": 100}}}}
    import copy
    cases = {"identical": (base, False)}
    c = copy.deepcopy(base); c["set"]["indoor"]["model"]["mae"] = float("nan"); cases["NaN value"] = (c, True)
    c = copy.deepcopy(base); c["set"]["indoor"]["model"]["mae"] = float("inf"); cases["inf value"] = (c, True)
    c = copy.deepcopy(base); c["setup"]["seed"] = 7; cases["changed setting"] = (c, True)
    c = copy.deepcopy(base); c["set"]["indoor"]["model"]["n"] = 99; cases["changed count"] = (c, True)
    c = copy.deepcopy(base); c["set"]["indoor"]["model"]["mae"] = 0.131; cases["error moved by 0.001"] = (c, True)
    c = copy.deepcopy(base); c["set"]["extra"] = {"x": 1.0}; cases["extra key"] = (c, True)
    c = copy.deepcopy(base); del c["set"]["indoor"]; cases["missing key"] = (c, True)
    ok = True
    for name, (new, should_fail) in cases.items():
        failed = bool(compare(base, new, STRICT_TOL))
        good = failed == should_fail
        ok &= good
        print(f"  {'ok ' if good else 'BAD'} {name}: {'rejected' if failed else 'accepted'}")
    print("selftest:", "PASS" if ok else "FAIL")
    return ok


def main():
    if "--selftest" in sys.argv:
        return 0 if selftest() else 1
    ok = True
    bad = check_checksums()
    print("checksums:", "PASS" if not bad else "FAIL | " + "; ".join(bad[:5]))
    ok &= not bad
    same_env = versions() == frozen_versions()
    tol = STRICT_TOL if same_env else RELAXED_TOL
    print(f"environment: {'same as the frozen run, strict tolerance ' + str(tol) if same_env else 'DIFFERENT from the frozen run (' + str(versions()) + '), relaxed tolerance ' + str(tol)}")
    with tempfile.TemporaryDirectory() as tmp:
        for script, extra in (("forecast_reference.py", ["--final"]), ("lunch_test.py", [])):
            subprocess.run([sys.executable, "-B", "-W", "ignore", str(root / "scripts" / script), "--data-dir", str(root / "data"),
                            "--out-dir", tmp, *extra], check=True, stdout=subprocess.DEVNULL)
        for name, f in (("forecast", "forecast_metrics.json"), ("lunch test", "lunch_test_summary.json")):
            problems = compare(json.loads((root / "reference_run" / f).read_text()), json.loads((Path(tmp) / f).read_text()), tol)
            print(f"{name}: {'PASS' if not problems else 'FAIL | ' + '; '.join(problems[:5])}")
            ok &= not problems
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
