#!/usr/bin/env python3
"""Reference implementation of the forecast experiment (see docs/FORECAST_TIMING_DEFINITION.md).

Predicts indoor temperature and HVAC power 15 minutes after the forecast origin on CU-BEMS Zone 4 and
compares a simple model (gradient boosting) with persistence and a schedule-based forecast.
The model is trained on the 2019 train split only. Validation and test are reported by default.
The 2018 independent test set is evaluated ONLY with --final, so it is used once, after the design is frozen.

Needs: pandas, numpy, scikit-learn (matplotlib optional, for the figure).
Example (from the package folder):  python scripts/forecast_reference.py --data-dir data --out-dir results
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

H = 4                       # target row = t + 4: the 5-minute mean that STARTS 15 min after the origin (end of row t)
EVENTS = [7 * 60 + 45, 11 * 60 + 50, 13 * 60, 16 * 60 + 25]    # AC start, lunch stop, restart, end (minutes of the day)
SEED = 42
VERSION = "v2"              # v2: contiguous-window rule (no gaps anywhere between t-12 and t); v1 allowed gaps between the lags used
LOOKBACK = 12              # longest lag, in rows


def load(path):
    return pd.read_csv(path, parse_dates=["timestamp"], index_col="timestamp")


def load_zone(data_dir, zone_id):
    """One zone of the all-zones file, in the same layout as the main file (for the zone-transfer check)."""
    z = pd.read_csv(Path(data_dir) / "CUBEMS_2019_Floor6_AllZones_real_long_5min.csv", parse_dates=["timestamp"])
    return z[z.zone_id == zone_id].drop(columns="zone_id").set_index("timestamp")


def last_completed_hour_weather(d, lag_hours=0):
    """Weather as available at the origin: last completed hourly value, no interpolation.

    Assumption: an hourly value is available at its label time (no delivery delay). Use lag_hours=1 as a
    sensitivity check for a one-hour delay. The 5-minute weather columns are interpolated; only the rows that sit on
    the original hourly points are used: temperature and humidity at minute 0, solar (hourly mean, centred) at minute 30."""
    t = d[d.index.minute == 0][["outdoor_temp_c", "outdoor_rh_pct"]]       # hourly observation labelled HH:00
    s = d[d.index.minute == 30][["solar_ghi_wm2"]]                         # mean of the preceding hour, centred at HH:30
    hr = (d.index + pd.Timedelta(minutes=5)).floor("h") - pd.Timedelta(hours=lag_hours)   # origin = end of row t
    wt = t.reindex(hr)
    wt.index = d.index
    ws = s.reindex(hr - pd.Timedelta(minutes=30))
    ws.index = d.index
    return pd.concat([wt, ws], axis=1)


def features(d, lag_hours=0):
    bad = d.good_row == 0
    ind, ac = d.indoor_temp_c.where(~bad), d.hvac_power_kw.where(~bad)
    X = pd.DataFrame(index=d.index)
    X["indoor"], X["power"] = ind, ac
    X["light"], X["plug"] = d.lighting_power_kw.where(~bad), d.plug_power_kw.where(~bad)
    for lag in (1, 3, 6, 12):
        X[f"indoor_l{lag}"], X[f"power_l{lag}"] = ind.shift(lag), ac.shift(lag)
    w = last_completed_hour_weather(d, lag_hours)
    X["out_t"], X["out_rh"], X["ghi"] = w.outdoor_temp_c, w.outdoor_rh_pct, w.solar_ghi_wm2
    tt = d.index + pd.Timedelta(minutes=5 * H)          # clock and calendar of the target time: known in advance
    m = tt.hour * 60 + tt.minute
    X["tod_sin"], X["tod_cos"] = np.sin(2 * np.pi * m / 1440), np.cos(2 * np.pi * m / 1440)
    X["workday"] = (tt.dayofweek < 5).astype(int)
    # Missing-data policy: every row from t-12 to t must be measured (good_row = 1). Gaps inside the window are not allowed.
    window_ok = (d.good_row == 1).rolling(LOOKBACK + 1).min() == 1
    return X.where(window_ok)


def targets(d):
    bad = d.good_row == 0
    return pd.DataFrame({"indoor": d.indoor_temp_c.where(~bad).shift(-H),
                         "power": d.hvac_power_kw.where(~bad).shift(-H)})


def schedule_profile(train):
    g = train[train.good_row == 1]
    k = pd.DataFrame({"m": g.index.hour * 60 + g.index.minute, "wd": (g.index.dayofweek < 5).astype(int),
                      "indoor": g.indoor_temp_c.values, "power": g.hvac_power_kw.values})
    return k.groupby(["wd", "m"])[["indoor", "power"]].median()


def schedule_forecast(d, prof):
    tt = d.index + pd.Timedelta(minutes=5 * H)
    idx = pd.MultiIndex.from_arrays([(tt.dayofweek < 5).astype(int), tt.hour * 60 + tt.minute])
    return prof.reindex(idx).set_axis(d.index)


def closure_days_by_rule(d):
    """Weekdays on which the zone's AC never exceeded 3 kW (at least 280 rows, 200 of them good). Same rule for every zone."""
    wd = d[d.index.dayofweek < 5]
    days = []
    for day, x in wd.groupby(wd.index.normalize()):
        g = x[x.good_row == 1]
        if len(x) >= 280 and len(g) >= 200 and g.hvac_power_kw.max() < 3:
            days.append(day)
    return pd.DatetimeIndex(days)


def near_switching(d):
    tt = d.index + pd.Timedelta(minutes=5 * H)
    m = tt.hour * 60 + tt.minute
    near = np.zeros(len(d), bool)
    for e in EVENTS:
        near |= ((m - e) >= 0) & ((m - e) <= 15) & (tt.dayofweek < 5)
    return near


def same_split(d, name):
    """True where the origin row and its target row (t + H) both belong to the split `name`."""
    return (d.suggested_split == name) & (d.suggested_split.shift(-H) == name)


def check_alignment():
    """Self-test of the timing definition: origin 10:05 (end of the 10:00 row) -> target = the row starting 10:20."""
    idx = pd.date_range("2019-04-01 09:00", periods=60, freq="5min")
    d = pd.DataFrame({"indoor_temp_c": idx.hour * 60.0 + idx.minute, "hvac_power_kw": 0.0, "good_row": 1,
                      "lighting_power_kw": 0.0, "plug_power_kw": 0.0,
                      "outdoor_temp_c": 0.0, "outdoor_rh_pct": 0.0, "solar_ghi_wm2": 0.0}, index=idx)
    y = targets(d)["indoor"]
    assert y.loc["2019-04-01 10:00"] == 10 * 60 + 20, "target must be the row starting 15 minutes after the origin"
    hourly = d.copy()
    hourly["outdoor_temp_c"] = np.where(idx.minute == 0, idx.hour, np.nan)          # hourly points only
    hourly["solar_ghi_wm2"] = np.where(idx.minute == 30, 100.0 + idx.hour, np.nan)
    w = last_completed_hour_weather(hourly)
    assert w.loc["2019-04-01 10:00", "outdoor_temp_c"] == 10, "at origin 10:05 use the 10:00 observation"
    assert w.loc["2019-04-01 09:55", "outdoor_temp_c"] == 10, "origin 10:00 -> 10:00 observation"
    assert w.loc["2019-04-01 10:00", "solar_ghi_wm2"] == 109, "at origin 10:05 use the mean of 09:00-10:00 (centred 09:30)"


def scores(y, p):
    e = (y - p).dropna()
    return {"mae": float(e.abs().mean()), "rmse": float(np.sqrt((e ** 2).mean())), "n": int(len(e))}


def evaluate(name, d, X, Y, mask, models, prof, closure_variants):
    # `mask` must already require origin and target in the same split (see same_split)
    sch = schedule_forecast(d, prof)
    near = pd.Series(near_switching(d), index=d.index)
    ok = mask & X.notna().all(axis=1) & Y.notna().all(axis=1) & sch.notna().all(axis=1)
    closure = {v: pd.Series(d.index.normalize().isin(days), index=d.index) for v, days in closure_variants.items()}
    out = {}
    for t in ("indoor", "power"):
        pred = pd.Series(models[t].predict(X[ok]), index=X.index[ok])
        forecasts = {"model": pred, "persistence": X[t][ok], "schedule": sch[t][ok]}
        y = Y[t][ok]
        out[t] = {
            "overall": {k: scores(y, v) for k, v in forecasts.items()},
            "near_switching": {k: scores(y[near[ok]], v[near[ok]]) for k, v in forecasts.items()},
            **{f"excluding_{v}": {k: scores(y[~c[ok]], f[~c[ok]]) for k, f in forecasts.items()} for v, c in closure.items()}}
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--out-dir", default="results")
    ap.add_argument("--final", action="store_true", help="also evaluate the 2018 year-transfer test set (use once)")
    ap.add_argument("--zone-transfer", metavar="ZONE_ID", help="also score the Z4-trained model on another zone's 2019 test period "
                    "(F6_Z1, F6_Z2, F6_Z5). These zones are reserved for the final claim: use once, after the design is frozen")
    ap.add_argument("--weather-lag-hours", type=int, default=0, help="sensitivity: delay of weather and solar readings")
    a = ap.parse_args()
    if a.zone_transfer:
        ap.error("Zone transfer is disabled in this draft: use the newer criteria-gated package and agree the success criteria first.")
    data, out_dir = Path(a.data_dir), Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    check_alignment()
    d19 = load(data / "CUBEMS_2019_Floor6_Zone4_real_merged_5min.csv")
    X19, Y19 = features(d19, a.weather_lag_hours), targets(d19)
    z4_closure_dates = pd.to_datetime(pd.read_csv(data / "weekday_ac_off_days.csv")["date"])     # Z4 dates, named as such
    tr = same_split(d19, "train")                      # no training label may come from the validation period
    prof = schedule_profile(d19[d19.suggested_split == "train"])
    fit_rows = tr & X19.notna().all(axis=1) & Y19.notna().all(axis=1)
    models = {t: HistGradientBoostingRegressor(max_iter=300, learning_rate=0.06, random_state=SEED)
              .fit(X19[fit_rows], Y19.loc[fit_rows, t]) for t in ("indoor", "power")}

    results = {"setup": {"horizon": "target = 5-minute mean starting 15 min after the origin (end of row t)",
                         "weather": "last completed hour, no interpolation", "weather_lag_hours": a.weather_lag_hours, "seed": SEED, "version": VERSION,
                         "missing_data_policy": "all rows t-12..t and the target row must be measured; no filling",
                         "train_rows_used": int(fit_rows.sum())}}
    for name in ("validation", "test"):
        results[f"2019_{name}"] = evaluate(name, d19, X19, Y19, same_split(d19, name), models, prof, {"closure_days": closure_days_by_rule(d19)})
    if a.final:
        d18 = load(data / "CUBEMS_2018_Floor6_Zone4_real_merged_5min.csv")
        results["2018_year_transfer"] = evaluate("2018", d18, features(d18, a.weather_lag_hours), targets(d18),
                                                 same_split(d18, "independent_test_2018"), models, prof,
                                                 {"closure_days": closure_days_by_rule(d18)})
    if a.zone_transfer:
        dz = load_zone(data, a.zone_transfer)
        prof_z = schedule_profile(dz[dz.suggested_split == "train"])        # the zone's own schedule baseline, not Z4's
        results["setup"]["zone_transfer_protocol"] = "docs/ZONE_TRANSFER_PROTOCOL.md"
        results[f"zone_transfer_{a.zone_transfer}_2019_test"] = evaluate(
            "zone", dz, features(dz, a.weather_lag_hours), targets(dz), same_split(dz, "test"), models, prof_z,
            {"closure_days": closure_days_by_rule(dz), "z4_closure_dates": z4_closure_dates})
    (out_dir / "forecast_metrics.json").write_text(json.dumps(results, indent=1))

    for key, res in results.items():
        if key == "setup":
            continue
        for t, unit in (("indoor", "C"), ("power", "kW")):
            o, n = res[t]["overall"], res[t]["near_switching"]
            print(f"{key:18s} {t:6s} n={o['model']['n']:6d} MAE[{unit}] model {o['model']['mae']:.3f} | persistence {o['persistence']['mae']:.3f} | "
                  f"schedule {o['schedule']['mae']:.3f} || RMSE {o['model']['rmse']:.3f} | {o['persistence']['rmse']:.3f} | {o['schedule']['rmse']:.3f}"
                  f" || near switching MAE: {n['model']['mae']:.2f} / {n['persistence']['mae']:.2f} / {n['schedule']['mae']:.2f}")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        sets = [k for k in results if k != "setup"]
        fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
        for a_, t, unit in ((ax[0], "indoor", "C"), (ax[1], "power", "kW")):
            w = 0.26
            for i, (m, c) in enumerate((("model", "#2e8b57"), ("persistence", "#7f8c8d"), ("schedule", "#2e7bb8"))):
                a_.bar(np.arange(len(sets)) + (i - 1) * w, [results[s][t]["overall"][m]["mae"] for s in sets], w, label=m, color=c)
            a_.set_xticks(range(len(sets)))
            a_.set_xticklabels(sets)
            a_.set_title(f"{'Indoor temperature' if t == 'indoor' else 'HVAC power'}: MAE 15 min ahead [{unit}]", loc="left", fontsize=10)
            a_.spines[["top", "right"]].set_visible(False)
        ax[0].legend(frameon=False)
        fig.tight_layout()
        fig.savefig(out_dir / "forecast_reference.png", dpi=130)
    except ImportError:
        print("matplotlib not installed: figure skipped")


if __name__ == "__main__":
    main()
