#!/usr/bin/env python3
"""Lunch-shutdown natural experiment: how much does the room warm after the AC stops at lunch?

The AC is switched off by a timer at about 11:50 and restarts at 13:00, regardless of the room temperature, so the
rise in indoor temperature over the following 65 minutes can be used to check a thermal model. This script selects the
days, reports the rise per day and its distribution (not only the mean), by month, by outdoor conditions, and for two
chronological halves of the days (so a model can be fitted on one half and checked on the other).

Needs: pandas, numpy.   Example:  python scripts/lunch_test.py --data-dir data --out-dir results
Selection rules (all must hold): Monday to Friday; 11:50 to 12:55 window has at least 85% good rows, mean AC power <= 1 kW
and maximum <= 3 kW; mean AC power between 09:00 and 11:30 is at least 8 kW (a normal working morning); the indoor
temperature at the first row (11:50) and the last row (12:55) of the window is measured (good_row = 1). Nothing is interpolated.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

START, N_ROWS = pd.Timedelta(hours=11, minutes=50), 14        # 11:50 .. 12:55, 13 intervals = 65 minutes


def select_days(d):
    rows = []
    wd = d[d.day_type == "weekday"]
    for day, _ in wd.groupby(wd.index.normalize()):
        w = d.loc[day + START: day + START + pd.Timedelta(minutes=5 * (N_ROWS - 1))]
        if len(w) < N_ROWS or (w.good_row == 1).mean() < 0.85:
            continue
        if w.hvac_power_kw.mean() > 1.0 or w.hvac_power_kw.max() > 3.0:
            continue
        pre = d.loc[day + pd.Timedelta(hours=9): day + pd.Timedelta(hours=11, minutes=30)]
        if pre.hvac_power_kw.mean() < 8:
            continue
        if w.good_row.iloc[0] != 1 or w.good_row.iloc[-1] != 1:      # start and end must be measured; nothing is interpolated
            continue
        t0, t1 = w.indoor_temp_c.iloc[0], w.indoor_temp_c.iloc[-1]
        rows.append({"date": day.date(), "month": day.month, "t_start": t0, "t_end": t1,
                     "rise_c": t1 - t0, "outdoor_c": w.outdoor_temp_c.mean(),
                     "solar_wm2": w.solar_ghi_wm2.mean(), "light_kw": w.lighting_power_kw.mean(),
                     "plug_kw": w.plug_power_kw.mean()})
    return pd.DataFrame(rows)


def make_figure(d, x, out_file, sim_c=5.0, sim_h=0.22, gains=(1.5, 2.5, 4.0)):
    """Real rebound (mean and middle 50% of the selected days) against the simulator's RC equation.
    Needs matplotlib. sim_c and sim_h are the simulator's thermal parameters (kWh/K and kW/K); the internal gains are
    assumed (a range), so the figure shows the shape of the mismatch, not a calibration."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rows = []
    for day in pd.to_datetime(x["date"]):
        w = d.loc[day + START: day + START + pd.Timedelta(minutes=5 * (N_ROWS - 1))]
        rows.append(w.indoor_temp_c.where(w.good_row == 1).values)          # missing rows stay missing, nothing is filled
    M = np.vstack(rows)
    mean, lo, hi = np.nanmean(M, 0), np.nanpercentile(M, 25, 0), np.nanpercentile(M, 75, 0)
    mins, t_out = np.arange(N_ROWS) * 5, x.outdoor_c.mean()

    def equation(g):
        t, out = mean[0], [mean[0]]
        for _ in range(N_ROWS - 1):
            t = t + (5 / 60) / sim_c * (sim_h * (t_out - t) + g)
            out.append(t)
        return np.array(out)

    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    fig, ax = plt.subplots(figsize=(9, 5.6))
    ax.fill_between(mins, lo, hi, color="#c0392b", alpha=.18, label="Real: middle 50% of days")
    ax.plot(mins, mean, color="#c0392b", lw=2.4, label=f"Real zone: mean of {len(x)} weekdays")
    ax.fill_between(mins, equation(gains[0]), equation(gains[2]), color="#2e7bb8", alpha=.25)
    ax.plot(mins, equation(gains[1]), color="#2e7bb8", lw=2.2, ls="--",
            label=f"Simulator equation (C={sim_c:g}, H={sim_h:g}), gains {gains[0]:g} to {gains[2]:g} kW")
    ax.text(mins[-1] + 1.5, mean[-1], f"Real:\n+{x.rise_c.mean():.1f} °C", color="#c0392b", va="center", fontsize=10, fontweight="bold")
    ax.text(mins[-1] + 1.5, equation(gains[1])[-1], f"Equation:\nabout +{equation(gains[1])[-1] - mean[0]:.1f} °C",
            color="#2e7bb8", va="center", fontsize=10, fontweight="bold")
    ax.set_xlim(-2, 82)
    ax.set_xlabel("Minutes after 11:50 (AC switched off by schedule, back on at 13:00)")
    ax.set_ylabel("Indoor temperature (°C)")
    ax.set_title("Lunch-hour AC shutdown: real rebound vs simulator's prediction equation", loc="left", fontsize=11.5)
    ax.legend(frameon=False, loc="upper left", fontsize=9)
    note = ("CU-BEMS 2019 Floor 6 Zone 4 (measured) vs the RC equation used by the optimizer, with the simulator's parameters.\n"
            "Start and end rows are measured (nothing interpolated). Different building size and climate; gains in the equation are assumed.\n"
            "Shows the shape of the mismatch, not a calibration.")
    fig.text(0.01, 0.008, note, fontsize=7.5, color="#555")
    fig.tight_layout(rect=[0, 0.09, 1, 1])
    fig.savefig(out_file, dpi=140)
    plt.close(fig)


def summary(x):
    r = x.rise_c
    return {"days": int(len(r)), "mean": round(float(r.mean()), 2), "std": round(float(r.std()), 2),
            "p10": round(float(r.quantile(.1)), 2), "p25": round(float(r.quantile(.25)), 2),
            "median": round(float(r.median()), 2), "p75": round(float(r.quantile(.75)), 2),
            "p90": round(float(r.quantile(.9)), 2)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--out-dir", default="results")
    ap.add_argument("--no-figure", action="store_true", help="skip the comparison figure (it needs matplotlib)")
    a = ap.parse_args()
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    res = {}
    for year in (2019, 2018):
        d = pd.read_csv(Path(a.data_dir) / f"CUBEMS_{year}_Floor6_Zone4_real_merged_5min.csv",
                        parse_dates=["timestamp"], index_col="timestamp")
        x = select_days(d).sort_values("date").reset_index(drop=True)
        x.to_csv(out / f"lunch_days_{year}.csv", index=False)
        half = len(x) // 2
        r = {"all": summary(x),
             "first_half_of_days": summary(x.iloc[:half]), "second_half_of_days": summary(x.iloc[half:]),
             "by_month": {int(m): summary(g) for m, g in x.groupby("month")},
             "outdoor_tercile": {}, "solar_tercile": {}}
        for col, key in (("outdoor_c", "outdoor_tercile"), ("solar_wm2", "solar_tercile")):
            q = pd.qcut(x[col], 3, labels=["low", "middle", "high"])
            r[key] = {str(k): summary(g) for k, g in x.groupby(q, observed=True)}
        res[str(year)] = r
        if year == 2019 and not a.no_figure:
            try:
                make_figure(d, x, out / "lunch_test_real_vs_equation.png")
            except ImportError:
                print("matplotlib not installed: figure skipped")
        print(f"{year}: {r['all']}")
        print(f"   first half {r['first_half_of_days']['mean']} (n {r['first_half_of_days']['days']}) | second half {r['second_half_of_days']['mean']} (n {r['second_half_of_days']['days']})")
    (out / "lunch_test_summary.json").write_text(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
