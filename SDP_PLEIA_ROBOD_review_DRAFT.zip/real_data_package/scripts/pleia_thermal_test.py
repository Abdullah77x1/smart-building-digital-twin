"""Exploratory analysis. Event interval was corrected after initial results were observed. Table: PLEIAData_2021_12rooms_10min.csv (10-minute rows). Rooms with a usable AC: A42, B12, B11, B10, B9, B16.
(1) Free-floating windows: runs of at least 3 h with no AC unit on. Windows start every hour from the measured temperature; horizons 1 h and 3 h.
    Models: no change; outdoor-only RC  dT/dt = a (To - T) + b G ; relaxation  dT/dt = k (Tb - T) ; RC + relaxation. Parameters fitted per room on windows
    that start before 1 July 2021, tested on windows from 1 July. G = solar radiation (kW/m2); no occupant or room-area assumption is needed.
(2) AC-stop events: the AC (at least one unit on for 1 h) switches off and stays off for 2 h; compare the first off-bin mean with the bin 60 min later. The interval correction was made after the original results were seen.
    The models fitted on free-floating windows predict the 60-minute change; compared with no change."""
import numpy as np, pandas as pd, json
from scipy.optimize import least_squares
d=pd.read_csv("PLEIAData_2021_12rooms_10min.csv"); d["t"]=pd.to_datetime(d.timestamp_utc)
ROOMS=["A42","B12","B11","B10","B9","B16"]; dt=1/6; SPLIT=pd.Timestamp("2021-07-01")
def sim(p,model,T0,To,G):
    a,b,k,Tb=p; T=np.empty(len(To)+1); T[0]=T0
    for i in range(len(To)):
        dT=0.0
        if model in("rc","both"): dT+=a*(To[i]-T[i])+b*G[i]
        if model in("relax","both"): dT+=k*(Tb-T[i])
        T[i+1]=T[i]+dt*dT
    return T[1:]
SPEC={"rc":([0.2,0.0,0,0],[0,-5,0,0],[5,10,0,0],lambda r:[0.2,0.5,0,0]),
      "relax":None,"both":None}
def pack(model,x,T0):
    if model=="rc": return [x[0],x[1],0,0]
    if model=="relax": return [0,0,x[0],x[1]]
    return [x[0],x[1],x[2],x[3]]
def fit(model,W):
    T0m=np.mean([w["T"][0] for w in W])
    if model=="rc": x0,lo,hi=[0.2,0.5],[0,-5],[5,20]
    elif model=="relax": x0,lo,hi=[0.2,T0m],[0,15],[5,40]
    else: x0,lo,hi=[0.1,0.5,0.1,T0m],[0,-5,0,15],[5,20,5,40]
    def res(x): 
        p=pack(model,x,T0m); return np.concatenate([sim(p,model,w["T"][0],w["To"][:-1],w["G"][:-1])-w["T"][1:] for w in W])
    f=least_squares(res,x0,bounds=(lo,hi),x_scale="jac"); return pack(model,f.x,T0m)
def segs(g,min_rows=18):
    on=(g.hvac_units_on>0).values; ok=g.hvac_units_on.notna().values&g.indoor_temp_c.notna().values&g.outdoor_temp_c.notna().values&g.solar_wm2.notna().values
    off=(~on)&ok; out=[]; i=0
    while i<len(g):
        if off[i]:
            j=i
            while j+1<len(g) and off[j+1]: j+=1
            if j-i+1>=min_rows: out.append((i,j))
            i=j+1
        else: i+=1
    return out
def windows(g,sg,steps):
    W=[]
    for a,b in sg:
        for s in range(a,b-steps+1,6):
            e=s+steps; blk=g.iloc[s:e+1]
            W.append(dict(t=g.t.iloc[s],T=blk.indoor_temp_c.values,To=blk.outdoor_temp_c.values,G=blk.solar_wm2.values/1000))
    return W
res={}; ev_all=[]
for r in ROOMS:
    g=d[d.room==r].reset_index(drop=True); sg=segs(g)
    tr=[s for s in sg if g.t.iloc[s[0]]<SPLIT]; te=[s for s in sg if g.t.iloc[s[0]]>=SPLIT]
    Wtr=windows(g,tr,6); 
    if len(Wtr)<50: print(r,"too few training windows",len(Wtr)); continue
    P={m:fit(m,Wtr) for m in ("rc","relax","both")}
    row={"train_windows":len(Wtr)}
    for hh,steps in ((1,6),(3,18)):
        W=windows(g,te,steps); 
        if not W: continue
        e={"no change":[]}; 
        for m in P: e[m]=[]
        for w in W:
            obs=w["T"][1:]; e["no change"].append(obs-w["T"][0])
            for m,p in P.items(): e[m].append(sim(p,m,w["T"][0],w["To"][:-1],w["G"][:-1])-obs)
        row[f"{hh}h"]={"n":len(W),**{k:float(np.sqrt(np.mean(np.concatenate(v)**2))) for k,v in e.items()}}
    res[r]=row
    # AC-stop events
    on=(g.hvac_units_on>0).values; ok=g.indoor_temp_c.notna().values
    for i in range(7,len(g)-13):
        if on[i-6:i].all() and (not on[i:i+12].any()) and g.hvac_units_on.iloc[i-6:i+12].notna().all() and ok[i] and ok[i+6] and g.t.iloc[i]>=SPLIT and g.hvac_cooling_on.iloc[i-6:i].max()>0:
            blk=g.iloc[i:i+7]  # from the first off bin (T0) through the bin 60 min later
            if blk.outdoor_temp_c.notna().all() and blk.solar_wm2.notna().all() and blk.indoor_temp_c.notna().all():
                T0=blk.indoor_temp_c.values[0]; To=blk.outdoor_temp_c.values[:-1]; G=blk.solar_wm2.values[:-1]/1000
                ev_all.append(dict(room=r,t=str(g.t.iloc[i]),obs=blk.indoor_temp_c.values[-1]-T0,**{m:sim(p,m,T0,To,G)[-1]-T0 for m,p in P.items()}))
for r,row in res.items():
    print(f"{r}: train windows {row['train_windows']} | "+" | ".join(f"{h} test n={row[h]['n']}: "+", ".join(f"{k} {v:.2f}" for k,v in row[h].items() if k!='n') for h in ('1h','3h') if h in row))
M=lambda h,k:np.mean([row[h][k] for row in res.values() if h in row])
for h in ("1h","3h"): print(f"\nMean over rooms, RMSE across the {h} window (C), test from 1 July:",{k:round(M(h,k),3) for k in ("no change","rc","relax","both")})
ev=pd.DataFrame(ev_all); print("\nAC-stop events (cooling, stays off 2 h), from 1 July:",len(ev),"events in rooms",ev.room.value_counts().to_dict() if len(ev) else {})
if len(ev):
    print("observed change in the next 60 min: mean %.2f C (10-90%%: %.2f to %.2f)"%(ev.obs.mean(),ev.obs.quantile(.1),ev.obs.quantile(.9)))
    for m in ("rc","relax","both"): print(f"  predicted by {m}: mean {ev[m].mean():.2f} | RMSE vs observed {np.sqrt(np.mean((ev[m]-ev.obs)**2)):.2f}")
    print("  no change: RMSE %.2f"%np.sqrt(np.mean(ev.obs**2)))
    ev.to_csv("pleia_ac_stop_events.csv",index=False)
json.dump(res,open("pleia_thermal_results.json","w"),indent=1,default=float)
