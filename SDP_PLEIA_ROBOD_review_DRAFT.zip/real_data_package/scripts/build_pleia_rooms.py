#!/usr/bin/env python3
"""Build a 10-minute room-level table for the 12 rooms of PLEIAData (University of Murcia, 2021) that have a presence sensor,
at least one HVAC unit and a temperature sensor. Source: Zenodo record 7620136 (CC BY 4.0), file Data_Nature.zip, folder raw_data.
Temperature and CO2 are not interpolated; HVAC states are carried forward for up to two additional 10-minute bins and motion states are inferred from the previous event. Rules (see the data card): 10-minute UTC grid; presence is marked missing during HVAC logging outages; temperature outside 10 to 40 C and CO2 outside 350 to 5000 ppm set to missing.
Usage: python build_pleia_rooms.py --raw-dir Data_Nature/raw_data --out PLEIAData_2021_12rooms_10min.csv"""
import argparse
import numpy as np, pandas as pd
ROOMS=[("A",37),("A",38),("A",42),("A",43),("B",9),("B",10),("B",11),("B",12),("B",15),("B",16),("B",17),("B",18)]
GRID=pd.date_range("2020-12-31 23:00","2021-12-31 22:50",freq="10min",tz="UTC")
def rel(raw,k): return pd.read_csv(f"{raw}/relations-{k}.csv",sep=";|,",engine="python")
def read(raw,f,sep,keep,cols):
    out=[]
    for ch in pd.read_csv(f"{raw}/{f}",sep=sep,chunksize=1_000_000,usecols=cols):
        out.append(ch[ch.IDdevice.isin(keep)])
    d=pd.concat(out)
    d["t"]=pd.to_datetime(d.Date.str.replace(r"\.\d+","",regex=True),format="%Y-%m-%d %H:%M:%S%z",utc=True)
    return d.drop(columns="Date")
def bins(t): return t.dt.floor("10min")
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--raw-dir",required=True); ap.add_argument("--out",required=True); a=ap.parse_args()
    raw=a.raw_dir
    R={k:rel(raw,k) for k in ("hvac","sensor","presence","CO2")}
    room_ids={k:{rm:set(R[k][(R[k].block==rm[0])&(R[k].room==rm[1])].ID.astype(int)) for rm in ROOMS} for k in R}
    allids={k:set().union(*room_ids[k].values()) for k in R}
    hv=read(raw,"data-hvac.csv",";",allids["hvac"],["IDdevice","Date","V4","V5","V12"])
    se=read(raw,"data-sensor.csv",";",allids["sensor"],["IDdevice","Date","V2"])
    pr=read(raw,"data-presence.csv",",",allids["presence"],["IDdevice","Date","V2"])
    co=read(raw,"data-CO2.csv",";",allids["CO2"],["IDdevice","Date","V17"])
    w=pd.read_csv(f"{raw}/MU62_dm.txt",sep=";",skipinitialspace=True); w.columns=[c.strip() for c in w.columns]
    w["t"]=pd.to_datetime(w.fecha.str.strip()+" "+w.hora.str.strip(),format="%d/%m/%y %H:%M:%S",utc=True)    # weather labels are UTC (solar peak check)
    w=w.set_index("t")[["tmed","hrmed","radmed","vvmed","dvmed","prec"]].apply(pd.to_numeric,errors="coerce")
    w=w[~w.index.duplicated()].reindex(GRID)
    w.columns=["outdoor_temp_c","outdoor_rh_pct","solar_wm2","wind_ms","wind_dir_deg","precip_mm"]
    frames=[]
    for rm in ROOMS:
        d=pd.DataFrame(index=GRID)
        # temperature: valid range, per-sensor 10-min mean, median over the room's sensors
        s=se[se.IDdevice.isin(room_ids["sensor"][rm])&(se.V2>=10)&(se.V2<=40)].copy(); s["b"]=bins(s.t)
        per=s.groupby(["IDdevice","b"]).V2.mean().unstack(0).reindex(GRID)
        d["indoor_temp_c"]=per.median(axis=1); d["n_temp_sensors"]=per.notna().sum(axis=1)
        # HVAC units: last log per bin, state kept at most 20 minutes (2 bins)
        h=hv[hv.IDdevice.isin(room_ids["hvac"][rm])].copy(); h["b"]=bins(h.t); h=h.sort_values("t")
        units=[]
        for dev,g in h.groupby("IDdevice"):
            g=g.groupby("b").last().reindex(GRID)
            ok=g.V4.ffill(limit=2).notna()
            st=g.V4.ffill(limit=2); mo=g.V5.ffill(limit=2); sp=g.V12.ffill(limit=2)
            units.append(pd.DataFrame({"on":st,"cool":((st==1)&(mo==2)).where(ok),"heat":((st==1)&(mo==1)).where(ok),"sp":sp.where((st==1)&(sp>=16)&(sp<=32))}))
        d["hvac_units"]=len(units)
        d["hvac_units_with_state"]=sum(u.on.notna().astype(int) for u in units)
        full=d.hvac_units_with_state==len(units)
        d["hvac_units_on"]=sum(u.on.fillna(0) for u in units).where(full)
        d["hvac_cooling_on"]=sum(u.cool.astype(float).fillna(0) for u in units).where(full)
        d["hvac_heating_on"]=sum(u.heat.astype(float).fillna(0) for u in units).where(full)
        d["hvac_setpoint_on_c"]=pd.concat([u.sp for u in units],axis=1).mean(axis=1)
        # presence: the sensor reports changes; the state is the last event at or before the end of the bin and persists until the next event.
        # It is set to missing during logging outages (no HVAC state for the room) and before the room's first event.
        p=pr[pr.IDdevice.isin(room_ids["presence"][rm])].sort_values("t")
        ev=p.set_index("t").V2.groupby(level=0).last()
        last=pd.DataFrame({"v":ev.values,"te":ev.index})
        m=pd.merge_asof(pd.DataFrame({"tb":GRID+pd.Timedelta(minutes=10)}),last.sort_values("te"),left_on="tb",right_on="te",direction="backward")
        d["presence"]=pd.Series(m.v.values,index=GRID).where(d.hvac_units_with_state>0)
        d["presence_events"]=pd.Series(0,index=GRID).add(p.assign(b=bins(p.t)).groupby("b").size().reindex(GRID),fill_value=0).astype(int)
        # CO2
        c=co[co.IDdevice.isin(room_ids["CO2"][rm])&(co.V17>=350)&(co.V17<=5000)].copy(); c["b"]=bins(c.t)
        d["co2_ppm"]=c.groupby(["IDdevice","b"]).V17.mean().unstack(0).reindex(GRID).median(axis=1)
        d=pd.concat([d,w],axis=1)
        d.insert(0,"room",f"{rm[0]}{rm[1]}"); d.insert(0,"timestamp_utc",GRID.strftime("%Y-%m-%d %H:%M:%S")); d.insert(1,"timestamp_local",GRID.tz_convert("Europe/Madrid").strftime("%Y-%m-%d %H:%M:%S%z"))
        d["good_row"]=(d.indoor_temp_c.notna()&d.hvac_units_on.notna()&d.outdoor_temp_c.notna()).astype(int)
        frames.append(d)
    out=pd.concat(frames,ignore_index=True)
    num=[c for c in out.columns if c not in ("timestamp_utc","timestamp_local","room")]
    out[num]=out[num].round(3)
    out.to_csv(a.out,index=False)
    print("rows",len(out),"| good rows",int(out.good_row.sum()),"(%.1f%%)"%(100*out.good_row.mean()))
if __name__=="__main__": main()
