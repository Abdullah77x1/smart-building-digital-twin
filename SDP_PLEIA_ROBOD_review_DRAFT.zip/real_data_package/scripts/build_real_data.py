#!/usr/bin/env python3
"""Rebuild the CU-BEMS real-data files from the raw files. Works offline.

Needs: pandas, numpy.
Inputs : raw 2018Floor6.csv and 2019Floor6.csv (figshare, doi 10.6084/m9.figshare.11726517),
         external/weather_bangkok_5min.csv and external/solar_bangkok_2018_2019_5min.csv
         (made by scripts/fetch_external.py, or the copies shipped in this package).
Outputs: three CSV files in --out-dir (same names as in data/).

Example (from the package folder):
  python scripts/build_real_data.py --raw-dir C:/path/to/raw --external-dir external --out-dir rebuilt --verify data
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

SOLAR = ["solar_ghi_wm2", "solar_direct_wm2", "solar_diffuse_wm2"]
ORDER_ZONE4 = ["timestamp", "outdoor_temp_c", "indoor_temp_c", "hvac_power_kw", "outdoor_rh_pct"] + SOLAR + [
    "valid_minutes_of_5", "good_row", "day_type", "lighting_power_kw", "plug_power_kw", "suggested_split"]
ORDER_LONG = ["timestamp", "zone_id", "outdoor_temp_c", "indoor_temp_c", "hvac_power_kw", "outdoor_rh_pct"] + SOLAR + [
    "lighting_power_kw", "plug_power_kw", "valid_minutes_of_5", "good_row", "day_type", "suggested_split"]
ZONES_LONG = ("z1", "z2", "z4", "z5")


def read_raw(path):
    raw = pd.read_csv(path)
    ts = pd.to_datetime(raw["Date"], format="%Y-%m-%d %H:%M:%S", errors="coerce")
    raw = raw[ts.notna()].copy()          # drops the corrupt last line of 2019Floor6.csv
    raw.index = pd.DatetimeIndex(ts[ts.notna()])
    raw = raw.sort_index()
    if raw.index.has_duplicates:
        raise ValueError(f"duplicate timestamps in {path}")
    return raw


def common_period(raw, zone):
    cols = [c for c in raw.columns if c.startswith(zone + "_")]
    return (max(raw[c].first_valid_index() for c in cols),
            min(raw[c].last_valid_index() for c in cols))


def zone_5min(raw, zone, start, end):
    minute = pd.date_range(start, end, freq="min")
    r = raw.reindex(minute)
    ac_cols = [c for c in raw.columns if c.startswith(zone + "_AC")]
    m = pd.DataFrame(index=minute)
    m["ac"] = r[ac_cols].sum(axis=1, min_count=len(ac_cols))      # all AC channels must exist
    m["t"] = r[f"{zone}_S1(degC)"]
    m["light"] = r[f"{zone}_Light(kW)"]
    m["plug"] = r[f"{zone}_Plug(kW)"]
    f = m[["ac", "t", "light", "plug"]].resample("5min").mean()
    f["valid"] = (m.ac.notna() & m.t.notna()).resample("5min").sum().astype(int)
    return f


def split_2019(idx):
    return np.where(idx < pd.Timestamp("2019-08-01"), "train",
                    np.where(idx < pd.Timestamp("2019-09-16"), "validation", "test"))


def compose(f, ext, split, zone_id=None):
    o = pd.DataFrame({"timestamp": f.index})
    if zone_id:
        o["zone_id"] = zone_id
    o["outdoor_temp_c"] = ext["outdoor_temp_c"].reindex(f.index).values
    o["indoor_temp_c"] = f["t"].round(3).values
    o["hvac_power_kw"] = f["ac"].round(3).values
    o["outdoor_rh_pct"] = ext["outdoor_rh_pct"].reindex(f.index).values
    for c in SOLAR:
        o[c] = ext[c].reindex(f.index).values
    o["lighting_power_kw"] = f["light"].round(3).values
    o["plug_power_kw"] = f["plug"].round(3).values
    o["valid_minutes_of_5"] = f["valid"].values
    o["good_row"] = ((f["valid"] >= 4) & f["t"].notna() & f["ac"].notna()).astype(int).values
    o["day_type"] = np.where(f.index.dayofweek >= 5, "weekend", "weekday")
    o["suggested_split"] = split
    return o


def verify(new, ref_path):
    ref = pd.read_csv(ref_path, parse_dates=["timestamp"])
    keys = ["timestamp"] + (["zone_id"] if "zone_id" in ref.columns else [])
    a = new.sort_values(keys).reset_index(drop=True)
    b = ref.sort_values(keys).reset_index(drop=True)
    if set(a.columns) != set(b.columns) or len(a) != len(b):
        return False, f"shape or columns differ ({len(a)} vs {len(b)} rows)"
    worst = 0.0
    for c in b.columns:
        if c == "timestamp":
            if not (a[c].values == b[c].values).all():
                return False, "timestamps differ"
        elif not pd.api.types.is_numeric_dtype(b[c]):
            if not (a[c].astype(str).values == b[c].astype(str).values).all():
                return False, f"text column {c} differs"
        else:
            x, y = a[c].astype(float).values, b[c].astype(float).values
            if not (np.isnan(x) == np.isnan(y)).all():
                return False, f"missing values differ in {c}"
            ok = ~np.isnan(x)
            d = np.abs(x[ok] - y[ok]).max() if ok.any() else 0.0
            worst = max(worst, d)
            if d > 1e-6:
                return False, f"{c} differs by up to {d:.4g}"
    return True, f"identical within rounding (largest difference {worst:.2g})"


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--raw-dir", required=True, help="folder with 2018Floor6.csv and 2019Floor6.csv")
    p.add_argument("--external-dir", default="external", help="folder with the weather and solar CSV files")
    p.add_argument("--out-dir", default="rebuilt")
    p.add_argument("--verify", help="folder with the shipped data/ files to compare against")
    a = p.parse_args()
    raw_dir, ext_dir, out_dir = Path(a.raw_dir), Path(a.external_dir), Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    w = pd.read_csv(ext_dir / "weather_bangkok_5min.csv", parse_dates=["timestamp"]).set_index("timestamp")
    s = pd.read_csv(ext_dir / "solar_bangkok_2018_2019_5min.csv", parse_dates=["timestamp"]).set_index("timestamp")
    ext = w.join(s, how="outer")

    results = {}
    # --- 2019: main zone file and all-zones file ---
    raw19 = read_raw(raw_dir / "2019Floor6.csv")
    start, end = common_period(raw19, "z4")
    f4 = zone_5min(raw19, "z4", start, end)
    results["CUBEMS_2019_Floor6_Zone4_real_merged_5min.csv"] = compose(f4, ext, split_2019(f4.index))[ORDER_ZONE4]
    parts = []
    for z in ZONES_LONG:
        f = zone_5min(raw19, z, start, end).reindex(f4.index)
        parts.append(compose(f, ext, split_2019(f4.index), zone_id=f"F6_{z.upper()}"))
    results["CUBEMS_2019_Floor6_AllZones_real_long_5min.csv"] = pd.concat(parts, ignore_index=True)[ORDER_LONG]
    # --- 2018: independent test set ---
    raw18 = read_raw(raw_dir / "2018Floor6.csv")
    s18, e18 = common_period(raw18, "z4")
    g4 = zone_5min(raw18, "z4", s18, e18)
    results["CUBEMS_2018_Floor6_Zone4_real_merged_5min.csv"] = compose(
        g4, ext, "independent_test_2018")[ORDER_ZONE4]

    status = 0
    for name, df in results.items():
        df.to_csv(out_dir / name, index=False)
        good = int(df["good_row"].sum())
        msg = f"{name}: {len(df)} rows, {good} good rows ({100 * good / len(df):.1f}%), missing outdoor temp {int(df['outdoor_temp_c'].isna().sum())}, missing solar {int(df['solar_ghi_wm2'].isna().sum())}"
        if a.verify:
            ok, why = verify(df, Path(a.verify) / name)
            msg += f" | check vs {a.verify}: {'PASS' if ok else 'FAIL'} ({why})"
            status |= 0 if ok else 1
        print(msg)
    return status


if __name__ == "__main__":
    sys.exit(main())
