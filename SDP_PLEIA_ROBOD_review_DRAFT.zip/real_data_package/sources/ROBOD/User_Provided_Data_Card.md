# Data card (draft): ROBOD, Rooms 3 and 4 (NUS SDE4, Singapore, 2021)

Status: **inspection only.** The files were not copied into the project package, and the **licence is not confirmed** (see section 6). Use ROBOD as a separate dataset; do not add its occupancy or other columns to CU-BEMS, FLEXLAB or NTU rows.

## 1. Source

ROBOD, room-level occupancy and building operation dataset. Tekler, Ono, Peng, Zhan, Lasternas, Chong. Building Simulation 15(12), 2127-2137 (2022), [https://doi.org/10.1007/s12273-022-0925-9](https://doi.org/10.1007/s12273-022-0925-9) . Repository (data, code, two description images): [https://github.com/ideas-lab-nus/robod](https://github.com/ideas-lab-nus/robod) . A figshare copy is cited by the authors' other repository (doi 10.6084/m9.figshare.19234530.v7); its record was not opened.

## 2. What it is (checked in the repository README, the two description images and the files)

- School of Design and Environment 4 (SDE4), National University of Singapore. Five rooms; 181 days at 5-minute sampling, 2021-09-07 to 2021-12-23, timestamps `YYYY-MM-DD HH:MM +08:00`.
- Room 3: office for administrative staff, level 5, floor area 98.4 m2, height 4.2 m, seating capacity 15. Room 4: office for researchers, level 3, 141.9 m2, height 4.1 m, seating capacity 25.
- Measured: indoor air temperature, humidity, illuminance, CO2, VOC, PM2.5, sound; Wi-Fi connected devices; energy (ceiling fan, lighting, plug load, chilled water, AHU/FCU fan); HVAC operation (supply air flow, damper, temperature setpoint, cooling-coil valve, fan speed, off-coil and supply air temperature, supply humidity, pressures); on-site outdoor weather including **measured global horizontal solar radiation** (pyranometer); and **ground-truth occupant presence and count from a camera**.

## 3. The two files used here

|                        | Room 3 (`combined_Room3.csv`, 3.4 MB) | Room 4 (`combined_Room4.csv`, 5.4 MB)  |
| ---------------------- | ------------------------------------- | -------------------------------------- |
| Rows (5 min)           | 8,352                                 | 13,536                                 |
| Days                   | 29 in 8 blocks                        | 47 in 12 blocks                        |
| Days of week           | Monday to Friday only                 | Monday to Friday only                  |
| Missing values         | 0.0 to 0.2% per column                | 0.0 to 0.1% per column                 |
| Occupant count         | 0 to 13, mean about 4.4 at midday     | 0 to 18, mean about 8 in the afternoon |
| Temperature setpoint   | **constant 25.0 C**                   | 25.3 to 28.0 C, mostly 26.5 C          |
| Indoor air temperature | 25.6 to 29.2 C (mean 27.3)            | 25.1 to 28.6 C (mean 27.4)             |

Columns (36): `timestamp, voc, sound_pressure_level, indoor_relative_humidity, air_temperature, illuminance, pm2.5, indoor_co2, wifi_connected_devices, ceiling_fan_energy, lighting_energy, plug_load_energy, chilled_water_energy, ahu_fan_energy, supply_air_flow, damper_position, temp_setpoint, cooling_coil_valve_position, cooling_coil_valve_command, ahu_fan_speed, offcoil_air_temp, offcoil_temp_setpoint, pressure_across_filter, supply_air_humidity, supply_air_pressure, supply_air_temperature, baromatic_pressure, dry_bulb_temp, global_horizontal_solar_radiation, wind_direction, wind_speed, outdoor_co2, rainfall_raw, outdoor_relative_humidity, occupant_presence, occupant_count`.

## 4. Checks made

- Row counts equal the number of days times 288, with a 5-minute step inside each block; the blocks are separated by gaps (the days were selected, not recorded continuously). Largest gap 68 days (Room 3) and 23 days (Room 4).
- `occupant_presence` is exactly "count above 0" in both rooms. Wi-Fi devices correlate with the count at 0.52 (Room 3) and 0.57 (Room 4), so Wi-Fi is a weak proxy.
- AC operation: supply air flow and chilled-water values switch on at about 08:00 to 08:15 and off at about 18:40 to 19:10 on every day, and are off at night (97 to 98% of night rows): a **timer-like schedule**, not demand-driven. At night the rooms sit close to the outdoor temperature (27.3 C indoor against 26.9 C outdoor).
- **The chilled-water energy is not a room-level cooling measure as it stands.** While the AC is on, `chilled_water_energy` times 12 (if it is kWh per 5 minutes) is about 27 kW (Room 3) and 64 kW (Room 4), whereas the sensible cooling computed from the room's own supply air (1.2 x 1.006 x flow / 3600 x (room - supply temperature)) is about 2.9 kW and 1.9 kW. The values are also coarse (many whole numbers). It probably belongs to a unit or meter serving more than the room, or the unit differs. Do not compare it with CU-BEMS electricity; the supply-air estimate (sensible only) is the more usable cooling signal. The authors' supplementary material should be read to settle this.
- Lighting energy in Room 3 is almost zero (mean 0.00 kWh per 5 minutes).

## 5. What it can and cannot do for the project

Can: study occupant count against temperature and AC operation in a hot-humid climate with measured solar radiation; test a one-zone thermal equation on rooms that follow the outdoor temperature at night; compare behavior with CU-BEMS and the simulator. Cannot: add occupants to CU-BEMS rows (other building, country and year); prove the effect of occupants on the AC (it runs on a timer, and the setpoint in Room 3 never changes); give weekends, AC-off days or a continuous record; give real savings. Short: 29 and 47 days, in blocks.

## 6. Licence and redistribution: not confirmed

The repository listing has no licence file and the README states no licence. The figshare record may. Until it is checked, keep the files outside the shared package and cite the source.

## 7. Open questions

Meaning and units of `chilled_water_energy` and which rooms the meter covers (supplementary material); whether 2021 conditions (the semester period) affected occupancy patterns; why the room stays 1 to 3 C above its setpoint in Room 3.

## 8. Test of the simulator's thermal equation on these rooms (analysis, not part of the data)

Protocol fixed before looking at results (script `robod_night_test.py`): AC-off segments are runs of at least 4 hours with supply air flow below 150 m3/h; windows start every hour from the measured temperature; the simulator's equation (C = 5 kWh/K and H = 0.22 kW/K per 120 m2, scaled to each room's floor area; 0.075 kW per person and 0.9 of plug and lighting electricity as gains) is run with the measured outdoor temperature and occupancy; C and H were also fitted on days before 1 Dec 2021 and tested on December.

- **After the evening AC stop** (about 18:40 to 19:10; 15 days in Room 3, 27 in Room 4) the real room temperature does not warm in the next 65 minutes (observed mean -0.02 C and -0.06 C). The equation predicts +0.16 C and +0.41 C. In CU-BEMS the room warmed about 3.8 C after the lunch stop.
- **Evenings and nights without AC are almost flat** (changes below 0.2 C per hour). On the December test windows, a "no change" forecast has RMSE 0.20 C (1 h) and 0.51 C (4 h) in Room 3, 0.29 and 0.41 C in Room 4; the scaled equation is worse (0.23 and 0.64 C; 0.32 and 0.63 C).
- The fitted C went to the upper bound I allowed (60 kWh/K) in both rooms: the data cannot identify a thermal capacity because the room hardly changes. No parameter values are claimed.
- Reading: the equation is not "too slow" here as in CU-BEMS; it is not accurate either. The two real buildings behave in opposite ways after an AC stop, so one parameter set cannot represent both. A tentative explanation (not tested): in these rooms the AC barely cools the air below the surrounding temperature (the room stays 1 to 2.5 C above its setpoint), so there is little to rebound from, whereas the CU-BEMS zone was cooled to about 22 C against surroundings near 26 C.
- Limits: 29 and 47 selected weekdays in blocks, one evening scenario, the lighting meter of Room 3 reads about zero (gains underestimated), occupant heat per person is assumed.

## 9. What ROBOD adds: three analyses (script `robod_value_analyses.py`; protocol fixed before running)

**A. Real internal gains against the simulator's parameters (weekdays 09:00 to 17:00).** Plug load is about 0.6 kW (Room 3) and 1.0 kW (Room 4) even with nobody present, against the simulator's standby 0.2 kW; the increase per person is 0.01 and 0.03 kW against 0.04 kW. Lighting in Room 4 is about 0.5 kW when the room is empty and 0.8 kW when occupied (the simulator: 0.9 kW when occupied only); the Room 3 lighting meter reads about zero. People: mean 3.8 (Room 3) and 6.3 (Room 4), 90th percentile 7 and 10, against capacities 15 and 25 and a simulator that fills 15 places. **B. Does occupancy or setpoint improve a 15-minute forecast?** Train before 1 Dec 2021, test December (3,120 examples per room), no gaps allowed. Persistence is hard to beat: MAE 0.076 C (Room 3) and 0.088 C (Room 4) for temperature. The gradient-boosting model gets 0.163 and 0.084 C with history and clock only; adding weather, solar, setpoint and occupancy changes Room 4 by 0.001 C or less and does not help Room 3. For supply air flow the model is also not better than persistence. So, in these rooms and at this horizon, no measurable value from occupancy or setpoint; the data are small and the AC runs on a timer. **C. A relaxation term.** Model for the 65 minutes after an AC stop: the room temperature relaxes toward a background temperature, T(t) = Tb - (Tb - T0) exp(-t / tau), two parameters per building, fitted on the first half of the days and tested on the second half. CU-BEMS lunch stop (138 days): tau 34 min, Tb 27.4 C; test RMSE 0.58 C against 2.57 C for no change and 2.01 C for the simulator equation. ROBOD evening stop (Room 3: 15 days; Room 4: 27 days): the fitted tau is very long (8 hours or more), the result equals "no change" (RMSE 0.06 to 0.07 C), and the simulator equation is worse (0.11 and 0.28 C). One form fits both buildings, with building-specific parameters; the simulator equation with fixed parameters fits neither.