# Data card: FLEXLAB (Berkeley) and NTU office (Singapore)

Real measured data, prepared separately from CU-BEMS. **Do not pool these rows with CU-BEMS or with synthetic data.** If combined for training, add a `building_id` and `data_origin` column and test on one real building at a time.

## Source
Sub-hourly measurement datasets from 6 real buildings (IEA EBC Annex 81). Data: https://data.mendeley.com/datasets/xztfbtsgys/3 (CC BY 4.0, credit the authors). Paper: https://doi.org/10.1016/j.dib.2023.109149 (Data in Brief 48, 2023, 109149). From the 6 datasets we used dataset 5 (FLEXLAB) and dataset 6 (NTU). Datasets 1 to 4 are other buildings and were only glanced at; their columns (radiators, heating, winter periods) suggest heating studies.

## 1. FLEXLAB: `FLEXLAB_2020_cellsAB_real_5min.csv`
Two side-by-side test cells (A and B) at Lawrence Berkeley National Laboratory, with measured loads and a site weather station. 1-minute source data, averaged to 5 minutes. 2020-07-09 11:00 to 2020-08-11 11:20, 9,509 rows per cell; good rows 8,875 per cell.

| Column | Meaning |
|---|---|
| `cell` | A or B |
| `indoor_temp_c` | mean of the two zone air sensors |
| `cooling_thermal_kw` | chilled-water thermal load, positive = cooling delivered (source column is negative for cooling) |
| `heating_thermal_kw` | hot-water thermal load |
| `fan_power_kw`, `pumps_power_kw` | measured electrical power of fan and water pumps. **Chiller and boiler electricity are not in these files**, so this is not total HVAC power. |
| `plug_power_kw`, `lighting_power_kw` | measured internal loads (these become heat in the cell) |
| `supply_air_temp_c`, `supply_air_flow_cmh` | supply air |
| `outdoor_temp_c`, `global_irradiance_wm2` | site weather (irradiance peaks at 13:00, so timestamps look like local time) |
| `cooling_setpoint_c`, `heating_setpoint_c` | zone setpoints, **cell A only** (blank for B; 13% missing for A) |
| `valid_minutes_of_5`, `good_row` | `good_row` = 1 if at least 4 of 5 minutes are valid and the main values exist |

Quality: 7.2% of minutes are missing, mostly one gap of 3,145 minutes (about 2.2 days) from 2020-07-17 17:01 in both cells; a few single minutes elsewhere.

Limits: Berkeley summer, daily mean outdoor temperature about 12 to 22 C (cool), so cooling is driven by internal loads and sun, not by heat. The cells are test rooms (57 m2 each per the paper) with heat-emitting mannequins instead of people; there is no occupancy count, no CO2. The weeks follow different control experiments (setpoints change).

Useful for: measured internal gains, solar and a cooling term in one small room, to test the thermal equation.

Checks done (preliminary, one-node model fitted by simulating 1 hour ahead; fit on 9 to 31 July, test on 1 to 11 August):
- The cooling load from the chilled-water meter (mean 0.47 kW in cell A) and the same load computed from supply-air flow and temperature (0.80 kW) disagree in level and only correlate at 0.75 (cell B: 0.36 vs 0.74 kW, 0.70). The cooling input is therefore uncertain.
- Cell A, basic model: C about 2.0 kWh/K and H about 0.065 kW/K, stable between the two periods. The simulator scaled to 57 m2 gives C 2.4 and H 0.105. Same order of magnitude, not a calibration.
- Cell B did not repeat it (C 3.2 kWh/K on the training period, 1.4 on the test period). The solar term came out near zero or negative.
- The model improves the 1-hour-ahead error only from 0.55 to 0.46 C (cell A) and 0.62 to 0.54 C (cell B) compared with "no change".
- **Conclusion: no reliable thermal parameters can be claimed from this data yet.**

## 2. NTU: `NTU_2018_2019_real_5min.csv`
Testbed office of 46 m2 in Singapore (hot, humid), 5-minute data as published.

| Column | Meaning |
|---|---|
| `case` | 1 = 2018-12-11 to 2019-01-13 (thermostat case); 2 = 2019-02-16 to 2019-03-20 (MPC case), as described in the paper |
| `room_temp_c`, `room_rh_pct` | room air |
| `supply_air_temp_c`, `supply_air_rh_pct`, `supply_air_mass_flow_kg_s` | supply air |
| `sensible_cooling_kw_derived` | **derived by us**: mass flow x 1.006 x (room - supply temperature). Sensible only; latent load is ignored although humidity is high. Not a measurement. |

Quality: 9,792 and 9,375 rows; largest gap 24 minutes (case 2). Timestamps were published as day/month/year; time zone not stated.

Limits: no outdoor weather, no electrical power, no occupancy, no setpoint column. The two cases are in different months, so differences between them are not a clean comparison of controllers. The AC runs roughly 08:00 to 18:00 (supply flow near zero at night).

Useful for: a small room in a hot-humid climate and a second example of how a room warms after the AC stops (about 1.2 C in 6 hours in case 1, average of all days; a rough number, not a fitted constant).
