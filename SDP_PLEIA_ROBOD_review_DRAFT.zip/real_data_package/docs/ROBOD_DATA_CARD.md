# ROBOD: source and integration checks

Status: **private review draft; source license not independently confirmed.** A third-party catalogue labels ROBOD CC BY 4.0, but the uploaded GitHub archive has no license file and the official Figshare license page could not be verified. Check the official record before redistribution. Do not present the license as confirmed.

## Source and attribution

- Original author repository: https://github.com/ideas-lab-nus/robod
- Source archive supplied by user: `robod-master.zip`
- Git archive commit: `6577c3b0fe734b6d6977cf23ef3ef8d79850d0c1`
- Supplied archive SHA-256: `54985d54b192c636adbcc8702b00e44c8f7a71283b8f39d0519137a0140c80c8`
- Research article: Tekler, Ono, Peng, Zhan, Lasternas and Chong (2022), https://doi.org/10.1007/s12273-022-0925-9
- Article cites Figshare v7: https://doi.org/10.6084/m9.figshare.19234530.v7. Equivalence of this GitHub archive to that exact version has not been verified.

## Included files

All five original room CSV files are in `data/ROBOD/` without any value changes. The supplied source README, notebook, images, and Revit model are in `sources/ROBOD/`. The notebook and Revit file have not been run or opened. `sources/ROBOD/User_Provided_Data_Card.md` is the earlier draft supplied by the user, copied verbatim; its claim that files are not in the package describes its original state and is superseded by this note.

## Inspection completed for this package

Timestamps were parsed as UTC-offset timestamps and checked for duplicates within each room; date counts are based on Singapore local time. These are selected days in blocks, not a continuous period. No values were imputed or changed.

| Room | Rows | Distinct local days | Columns | Missing air temperature | Missing occupant count |
|---|---:|---:|---:|---:|---:|
| 1 | 8,352 | 29 | 28 | 0 | 0 |
| 2 | 8,352 | 29 | 28 | 0 | 0 |
| 3 | 8,352 | 29 | 36 | 0 | 0 |
| 4 | 13,536 | 47 | 36 | 0 | 0 |
| 5 | 13,536 | 47 | 36 | 0 | 0 |

Room 5 has 2,580 missing `supply_air_flow` values. The five raw files have timestamp, indoor temperature, setpoint and occupancy fields; rooms 1 and 2 use FCUs and have fewer HVAC columns than rooms 3-5. Their field meanings and meter coverage must be checked before modelling.

`chilled_water_energy` is not directly interchangeable with electrical AC power. See the supplied draft card for earlier hypotheses and reported results. The named project scripts `robod_night_test.py` and `robod_value_analyses.py` were not present in the uploaded archive, so those reported results were not independently reproduced. No forecasting model, comparison or reserved-zone test was run as part of this addition.

Files from different buildings remain separate. The original dataset must not be treated as CU-BEMS occupancy, and any comparison between buildings must account for different times, equipment and conditions.

## Integrity

A separate SHA-256 manifest of added files is at `reference_run_robod/checksums_sha256.txt`. The original reference manifest, code, results and the disabled reserved-zone guard have been preserved. The base project archive was SHA-256 `0554972bba6a6f4febcacdb1a7c0990f4af16e65e7133a5e59a6c86b91070f0d`.
