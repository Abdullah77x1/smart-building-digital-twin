# Data card: CU-BEMS 2019, Floor 6 Zone 4, merged with outdoor weather

File: `CUBEMS_2019_Floor6_Zone4_real_merged_5min.csv`  
Type: **real measured data** (not synthetic). Keep it separate from `building_simulation_data.csv`.

## 1. Sources

| Part | Source | Licence / terms |
|---|---|---|
| Indoor temperature, HVAC power | CU-BEMS dataset, Chulalongkorn University, Bangkok. Paper: https://doi.org/10.1038/s41597-020-00582-3 . Data: https://doi.org/10.6084/m9.figshare.11726517 (file `2019Floor6.csv`) | CC BY 4.0 (checked on the figshare record, version 4). Credit the authors. |
| Outdoor temperature, humidity | Meteostat, station 48455 (Bangkok Metropolis, 13.73 N, 100.56 E), hourly | CC BY-NC 4.0 (non-commercial, credit Meteostat). Meteostat can fill gaps with model values; we could not tell which hours were observed. |

## 2. Columns

| Column | Meaning |
|---|---|
| `timestamp` | Start of the 5-minute interval, Bangkok time (UTC+7) |
| `outdoor_temp_c`, `outdoor_rh_pct` | Station values, hourly, linearly interpolated to 5 min |
| `solar_ghi_wm2`, `solar_direct_wm2`, `solar_diffuse_wm2` | Solar radiation on a horizontal surface (W/m2): global, direct, diffuse. **Modeled** (ERA5 reanalysis via Open-Meteo, point 13.73 N 100.56 E), hourly mean of the preceding hour shifted 30 min and interpolated to 5 min. Not measured at the building. |
| `indoor_temp_c` | Zone 4 sensor `z4_S1(degC)`, mean of the valid minutes in the interval |
| `hvac_power_kw` | `z4_AC1 + z4_AC2 + z4_AC3 + z4_AC4` (kW electrical), mean of valid minutes. A minute counts only if all four channels exist. |
| `lighting_power_kw`, `plug_power_kw` | Zone 4 lighting `z4_Light(kW)` and plug load `z4_Plug(kW)`, mean of valid minutes (88 and 85 rows missing). Activity proxies, not occupancy. |
| `valid_minutes_of_5` | Minutes (0 to 5) that had both HVAC power and indoor temperature |
| `good_row` | 1 if `valid_minutes_of_5 >= 4` and both measured values exist; use only these rows for fitting and scoring |
| `suggested_split` | `train` (to 2019-07-31), `validation` (2019-08-01 to 2019-09-15), `test` (from 2019-09-16). A suggestion so everyone uses the same split; the test part should not be used for tuning. |
| `day_type` | `weekday` (Mon to Fri) or `weekend` (Sat, Sun); public holidays are not removed |

### Second file (optional): `CUBEMS_2019_Floor6_AllZones_real_long_5min.csv`
Same columns plus `zone_id`, for zones Z1, Z2, Z4, Z5 of Floor 6 (Z3 has no AC and no temperature sensor, so it is left out). Good rows: Z1 62,926; Z2 58,781; Z4 65,249; Z5 64,755 (of 66,226 each). Zone sizes and AC capacities differ and are not known: do not pool zones without `zone_id`. Z4 in this file is identical to the main file (checked).

### Third file (separate test set): `CUBEMS_2018_Floor6_Zone4_real_merged_5min.csv`
Same zone (Z4) and same columns, summer 2018: 2018-07-01 to 2018-09-14 (the only period with both temperature and HVAC power in 2018), 21,888 rows every 5 minutes, good rows 19,987 (91.3%). Built the same way (raw `2018Floor6.csv`, outdoor weather from Meteostat 48455 shifted +7 h and interpolated); the 1-minute counts match the earlier check (109,440 minutes, 102,390 complete). Weather timing check: on 21 weekend days with the AC off, indoor temperature follows outdoor best with a 1-hour lag (correlation 0.87; a 7-hour error would give about -0.51 or -0.01). Use it as a **year-transfer test set**: a different year, never used for fitting (`suggested_split` = `independent_test_2018`). Its reference results have been seen, so it is not an unseen set. Do not append it to the 2019 table. Weaker than 2019: more missing sensor minutes, and only 17 clean lunch-shutdown days (mean rebound 3.65 C in 65 min against 3.82 C in 2019; see `scripts/lunch_test.py`).

## 3. Processing (nothing measured was filled or smoothed)

1. Raw file read as is; one corrupt last row (`2`) excluded.
2. Columns `z4_*` selected; period limited to when temperature and HVAC both exist.
3. 1-minute data averaged to 5 minutes.
4. Hourly weather shifted +7 h (it was in UTC), interpolated to 5 min, joined by timestamp.
5. Solar radiation fetched from Open-Meteo (hourly, local time, mean of the preceding hour), shifted 30 min to the middle of that hour, interpolated to 5 min, joined by timestamp (checked: direct + diffuse equals global; no missing values; daytime mean about 656 W/m2 between 10:00 and 14:00).
6. Reproducibility: the three CU-BEMS files are rebuilt from the raw figshare files with `scripts/build_real_data.py` (offline, using the weather and solar copies in `external/`). The rebuilt files are byte-identical to the shipped ones. Expected raw checksums: `2019Floor6.csv` MD5 4f2446b38b566f2c1a07bf0e44587b42 (matches figshare); `2018Floor6.csv` MD5 e4074802fd7973a87e620a9ea1a381b6 (our copy, not compared with the figshare record).

## 4. Checks run on the merged file

- Re-derived from the raw file `2019Floor6.csv` (independent run): HVAC power and indoor temperature match this file within 0.001 and have the same missing rows.
- 66,226 rows, 2019-03-06 14:40 to 2019-10-22 13:25; exactly every 5 minutes, no gaps, no duplicates.
- Good rows: 65,249 (98.52%). Missing: HVAC 99 rows, indoor temperature 588 rows.
- Ranges: HVAC 0 to 43.66 kW; indoor 18.1 to 32.0 °C; outdoor 24.2 to 39.3 °C. One row above 40 kW is kept and should be reviewed.
- The 59.55 kW minute of 2019-09-16 is not in this file (not all four channels were present that minute); it is listed in `2019_Zone4_flagged_readings.csv`.
- **Time alignment of weather:** on 59 weekend days with the AC off, indoor temperature follows outdoor temperature best when outdoor is 1 hour earlier (correlation 0.82; 0.81 at 0 h). A 7-hour error would give about -0.47 or 0.03. So the +7 h shift is well supported.

## 5. Known limits

- The data file ends on 2019-10-22 although the paper describes data to 31 Dec 2019.
- Source file verified: the downloaded `2019Floor6.csv` matches the figshare record (MD5 4f2446b38b566f2c1a07bf0e44587b42, 59.81 MB), so the early end is in the published file itself (last full row 2019-10-22 13:27, followed by a corrupt line, excluded).
- Solar check: on 59 weekend days with the AC off, adding the solar columns improves a one-node free-float fit only slightly (daily RMSE 0.73 to 0.68 C; 1.40 C for no change), and the fitted parameters are unstable. No reliable thermal parameters are claimed.
- No occupancy count; solar radiation is modeled (reanalysis), not measured. Weekday schedule from the data: AC on 07:45 to 11:50 and 13:00 to 16:25 (start, lunch stop, restart and end each within about 5 minutes on 80% of working weekdays, 2019 and 2018; see `real_operating_schedule_summary.csv`). Lighting drops only about 15% at lunch (about 3.9 to 3.3 kW) and plug load about 7%, so they are weak presence proxies. State this when using them.
- Zone area is not known; the zone is much larger than the 120 m² simulated office. Compare behaviour and shape, not absolute kW.
- The room is about 3.6 °C cooler than outdoors on average even with the AC off, so it is not coupled to outdoor air only. Thermal constants (C, H) could not be reliably estimated (methods gave 9 to 45 h).
- Outdoor values may include model-filled hours.

## 6. What can and cannot be claimed

Can: the simulator was compared with real measured operation (schedule, temperature level, daily energy shape) from a hot-climate office building.  
Cannot: that the optimizer saved energy in a real building (the real building never ran it); that the simulator is calibrated; anything about occupants.

## 7. Merging rules

- Do **not** append these rows to synthetic data. Keep a separate file and a label (`real` vs `synthetic`).
- Do not merge 2018 into this table. Summer 2018 (1 Jul to 14 Sep, temperature available) is a separate test set.
- Suggested use: fit on the first part of the period, test on a later period never used for fitting.

## 8. Citation and licence

Solar radiation: Open-Meteo.com Historical Weather API (ERA5 reanalysis), https://open-meteo.com ; CC BY 4.0, attribution required (check terms on the site).


Pipattanasomporn, Manisa; Chitalia, Gopal; Songsiri, Jitkomut; Aswakul, Chaodit; Pora, Wanchalerm; Suwankawin, Surapong; et al. (2020). CUBEMS, a smart building electricity consumption and indoor environmental sensor dataset. figshare. Dataset. https://doi.org/10.6084/m9.figshare.11726517.v4

Licence: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
