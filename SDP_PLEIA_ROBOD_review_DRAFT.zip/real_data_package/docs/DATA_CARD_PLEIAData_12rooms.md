# Data card: PLEIAData, 12 rooms, 10-minute table (University of Murcia, 2021)

Derived from real measurements. Temperature and CO2 were not interpolated; HVAC states were carried forward for up to two subsequent bins and motion state was inferred by carrying the last sensor event forward. Built by `scripts/build_pleia_rooms.py` from the raw source files. The raw files are not included and rebuilding was not independently verified for this integration.

## 1. Source and licence (checked)
PLEIAData: consumption, HVAC (Heating, Ventilation & Air Conditioning), temperature, weather and motion sensor data for smart buildings applications. Martínez Ibarra, A.; González-Vidal, A.; Skarmeta Gómez, A. Zenodo, version v3, published 16 Sep 2022, https://doi.org/10.5281/zenodo.7620136 . **Licence: Creative Commons Attribution 4.0 (CC BY 4.0)**, read on the record's page. The submitted data card reported that the source archive matched MD5 3a65b744ce960c0bced4285c7cc6d3d4; the raw archive was not provided for independent verification. Article: Scientific Data (2023), https://www.nature.com/articles/s41597-023-02023-3 . Funded by the European project PHOENIX (grant 893079). Weather: IMIDA station (file `MU62_dm.txt`). Credit the authors when using this table.

## 2. Building and rooms
Pleiades building, University of Murcia (Spain), blocks A, B and C; hot summers (hourly outdoor maximum 45.8 C in August, monthly mean 24 to 28 C from June to September) and cool winters. The table covers the **12 rooms that have a presence sensor, at least one HVAC unit and a temperature sensor**: A37, A38, A42, A43, B9, B10, B11, B12, B15, B16, B17, B18. Room areas are not given.

## 3. Table: `PLEIAData_2021_12rooms_10min.csv`
630,720 rows (12 rooms x 52,560 ten-minute rows), 1 Jan 2021 00:00 local time to 31 Dec 2021 23:50. `good_row` = 1 in 87.4% of rows.

| Column | Meaning |
|---|---|
| `timestamp_utc`, `timestamp_local` | Start of the 10-minute bin, on a regular UTC grid; local time (Europe/Madrid) with its offset |
| `room` | A37 etc. |
| `indoor_temp_c`, `n_temp_sensors` | Median over the room's sensors of the 10-minute mean; readings outside 10 to 40 C set to missing |
| `hvac_units`, `hvac_units_with_state` | Units in the room; units with a state in the bin (a state may be carried forward into up to two subsequent 10-minute bins after the bin with the last log) |
| `hvac_units_on`, `hvac_cooling_on`, `hvac_heating_on` | Units on; units on in cooling mode; units on in heating mode (missing unless every unit has a state) |
| `hvac_setpoint_on_c` | Mean setpoint of units that are on (16 to 32 C only) |
| `presence`, `presence_events` | Inferred binary motion state (0 or 1) and the number of sensor events in the bin. The last recorded state is carried forward; it is marked missing during HVAC logging outages. The motion sensor is not a direct count of people and a lack of motion does not prove an empty room |
| `co2_ppm` | Median over the room's CO2 sensors; readings outside 350 to 5000 ppm set to missing |
| `outdoor_temp_c`, `outdoor_rh_pct`, `solar_wm2`, `wind_ms`, `wind_dir_deg`, `precip_mm` | Weather station, 10-minute values (not interpolated) |
| `good_row` | 1 if indoor temperature, HVAC state and outdoor temperature are all present; this does not require presence, CO2 or solar data |

Time: weather labels are **assumed UTC** based on a solar-peak check; this is not independent confirmation of the source time-zone convention. HVAC and sensor logs carry explicit offsets and were converted to UTC.

## 4. Quality
- Coverage: indoor temperature 98%, HVAC state 93%, outdoor weather 94%, presence 79 to 93%, CO2 high only in A42, B10 and B11 (93 to 98%), 55% in B16, 34% in A38, and 13% or less (0% in A37, A43, B15) elsewhere.
- Logging gaps (HVAC logs): **2 to 19 May (17.4 days)**, 12 to 16 Aug (3.9 days), 10 to 13 Dec (2.7 days). The weather file has gaps too.
- **Most units are almost never used.** Share of time on: A42 40%, B12 31%, B11 6%, B10 5%, B9 4%, B16 2%, B18 2%, B17 0.4%, A37 0.2%, A38, A43 and B15 about 0%. For AC dynamics only A42, B12, B11, B10, B9 and B16 are really usable.
- **Inferred motion-state=1 is sparse:** in weekday 08:00 to 20:00 rows, motion-state=1 rows per room (10-minute rows): B10 2,619; B12 2,562; B11 1,749; B9 1,528; B16 1,206; A42 484; B17 278; B18 160; A37 86; B15 40; A43 29; A38 17. Ratios for the last five rooms are unreliable.
- Pooled over the 12 rooms (weekdays 08:00 to 20:00): AC on in 37% of inferred motion-state=1 rows (10,758) and 9% of inferred motion-state=0 rows (188,570). These states are not confirmed occupied/empty labels.
- We did not use the processed files of the record: they replace extreme temperature values with the last valid value and smooth consumption.

## 5. Not included
Block-level electricity data, temperature sensors of other rooms, and other HVAC units are not included in this derived table. The source paper describes aggregated consumption of monitored HVACs per block, with no meter for each room. This table has no per-unit HVAC electricity: only on/off, mode and setpoint per unit.

## 6. What it can and cannot do
Can: study AC use against occupancy and weather in a hot climate; test a thermal equation on AC on/off events and free-floating periods with measured solar radiation. Cannot: calibrate HVAC electricity; give occupant counts; show real savings; say anything about room size.

## 7. Reproduce
`python scripts/build_pleia_rooms.py --raw-dir /path/to/Data_Nature/raw_data --out rebuilt_PLEIAData.csv` (needs pandas and numpy; reads about 1.3 GB of raw CSV in chunks; 2 to 3 minutes).

## 8. Exploratory thermal-equation tests (corrected integration draft)

Run from the package root: `cd data` then `python ../scripts/pleia_thermal_test.py`. Results are exploratory; they were revisited after the initial results had been seen. The code requires numpy, pandas and scipy. It uses recorded outdoor temperature and radiation within each evaluation window, so these results are not an operational forecast using only data available at the start.

Rooms: A42, B12, B11, B10, B9, B16. Areas are unknown; the equation structure was fitted separately per room, not calibrated from area-scaled original simulator parameters. Windows start hourly, so they overlap. Split: windows from segments starting before July 2021 for fitting; later segments for testing. The reported window RMSE averages errors across each entire window, not just the final 1 h or 3 h endpoint.

- Mean across rooms: for the 1 h window, no-change RMSE 0.326 C, outdoor RC + solar 0.318 C, relaxation-only 0.326 C, combined 0.321 C. For the 3 h window: 0.547, 0.520, 0.552 and 0.531 C respectively. The combined model shows no improvement over RC + solar in this exploratory comparison.
- The supplied script originally measured each AC-stop temperature change from the final ON bin to 60 min after the first OFF bin: a **70-minute span**, although its report called it 60 minutes. It has been corrected to use the first OFF bin through the bin 60 minutes later. On the same 100 selected events, the measured mean is 0.76 C (10th–90th percentile -0.03 to 1.93 C); the RC model mean is 0.15 C, RMSE 0.98 C versus 1.07 C for no change. These are binned averages, not an instantaneous measurement at switch-off.
- The earlier 70-minute run reported a 0.74 C mean; it must not be presented as a 60-minute result. The supplied regression on presence was not accompanied by reproducible code and has not been independently reproduced.
- Events were selected after observing the data, are observational and user-driven, and 46 of the 100 are from B11. They do not establish the causal effect of changing HVAC operation or evidence of real energy savings. Different buildings and different shutdown times should not be treated as a controlled comparison.

## 9. Integration verification

The delivered 12-room table has 630,720 rows, 12 room identifiers, 0 duplicate room/timestamp pairs, and 551,166 `good_row` entries (87.4%). `good_row` requires only temperature, HVAC state and outdoor temperature. The raw PLEIAData and the latest criteria-gated main package were not supplied for verification. The table's weather time-zone assumption and carried-forward motion states require further validation before occupancy or control claims.
