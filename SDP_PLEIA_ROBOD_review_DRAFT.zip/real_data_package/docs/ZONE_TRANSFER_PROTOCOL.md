# Zone-transfer protocol (frozen before any reserved zone is run)

**Status:** no model has been run on zones Z1, Z2 or Z5 by the author of the reference code. The code path was checked only with Z4 as a stand-in (the result equals the Z4 test result). Zones that were run, looked at in a model comparison, or used to choose a change are no longer reserved.

## 1. What this test can and cannot show
It checks whether a model trained on Z4 carries over to other zones of the **same building in the same period** (2019). It does not show real energy savings, the effect of changing the AC operation, or transfer to another building or another year. Zones differ in size and AC capacity (mean AC power over the 2019 period: Z1 4.4 kW, Z2 3.7 kW, Z4 4.1 kW, Z5 1.5 kW), so power errors in kW are not comparable across zones.

## 2. What is evaluated
- The reference model trained on the Z4 2019 **train** split only. No refit, no rescaling, no tuning.
- Zones `F6_Z1`, `F6_Z2` and `F6_Z5`, each on its own 2019 **test** split (16 Sep to 22 Oct 2019).
- The timing definition and the missing-data policy of `docs/FORECAST_TIMING_DEFINITION.md`; targets: indoor temperature and total HVAC power, 15 minutes ahead.

## 3. Baselines
- **Persistence:** the last observed value.
- **Schedule:** the median at the target time of day, by day type, built from **the evaluated zone's own** 2019 training split (not from Z4).

## 4. What to report
- All three zones. No selection of zones.
- MAE, RMSE and number of examples for model, persistence and schedule; also errors near the switching times.
- Three variants: all days; excluding **the zone's own closure days** (a weekday on which that zone's AC never exceeded 3 kW, with at least 280 rows and 200 good rows; same rule for every zone, computed by the script); excluding **Z4's closure dates** (`data/weekday_ac_off_days.csv`), named as such in the output (`excluding_z4_closure_dates`). Z4's dates are not assumed to be closure days of another zone.

## 5. Before running
The team writes the success criteria first (for example: the model beats persistence and the zone's own schedule for temperature; for power, a tolerance relative to the zone's AC capacity). Expect larger power errors because of scale differences.

## 6. Run once
```
python scripts/forecast_reference.py --data-dir data --out-dir results_zone_F6_Z1 --zone-transfer F6_Z1
python scripts/forecast_reference.py --data-dir data --out-dir results_zone_F6_Z2 --zone-transfer F6_Z2
python scripts/forecast_reference.py --data-dir data --out-dir results_zone_F6_Z5 --zone-transfer F6_Z5
```
If the design is changed after seeing any of these results, the zones are no longer reserved: say so and report both versions.

## 7. Data note
Good rows (of 66,226 five-minute rows): Z1 62,926; Z2 58,781; Z5 64,755. The contiguous-window rule removes more examples where a sensor has gaps (Z2 the most).
