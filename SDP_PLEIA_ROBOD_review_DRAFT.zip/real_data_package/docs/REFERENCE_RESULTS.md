# Reference run v2: frozen results and limits

Files: `reference_run/` (metrics JSON, per-day lunch results, figure, `environment.txt`, `checksums_sha256.txt`). Re-run and compare with `python scripts/check_reference.py` (counts must match; errors may move slightly with other library versions). Definitions and rules: `docs/FORECAST_TIMING_DEFINITION.md`.

## What was run
`python scripts/forecast_reference.py --data-dir data --out-dir reference_run --final` and `python scripts/lunch_test.py --data-dir data --out-dir reference_run`. Gradient boosting (scikit-learn), seed 42, trained on the 2019 train split only. The reserved zones (Z1, Z2, Z5) were **not** run.

## Forecast results (MAE / RMSE; 15 minutes ahead)
| Set | Target | Examples | Model MAE / RMSE | Persistence MAE / RMSE | Schedule MAE / RMSE |
|---|---|---|---|---|---|
| 2019 validation | Temperature (°C) | 11,983 | 0.111 / 0.216 | 0.265 / 0.676 | 0.798 / 1.108 |
| 2019 validation | Power (kW) | 11,983 | 0.311 / 1.069 | 1.178 / 4.677 | 0.459 / 2.100 |
| 2019 test | Temperature (°C) | 9,577 | 0.130 / 0.255 | 0.258 / 0.663 | 0.965 / 1.323 |
| 2019 test | Power (kW) | 9,577 | 0.396 / 1.380 | 1.212 / 4.675 | 0.532 / 2.320 |
| 2019 test, without closure days | Temperature (°C) | 9,324 | 0.131 / 0.257 | 0.263 / 0.671 | 0.906 / 1.156 |
| 2019 test, without closure days | Power (kW) | 9,324 | 0.406 / 1.399 | 1.245 / 4.738 | 0.406 / 1.641 |
| 2018 year-transfer | Temperature (°C) | 8,940 | 0.352 / 0.665 | 0.319 / 0.745 | 1.170 / 1.521 |
| 2018 year-transfer | Power (kW) | 8,940 | 2.104 / 5.033 | 3.061 / 8.073 | 2.483 / 5.709 |

## Lunch-shutdown experiment (temperature rise in 65 minutes after the AC stops)
| Year | Days | Mean rise | Spread (10th to 90th percentile) | First half of days | Second half |
|---|---|---|---|---|---|
| 2019 | 138 | 3.82 C | 3.12 to 4.55 C | 4.07 C | 3.56 C |
| 2018 | 17 | 3.65 C | 3.30 to 4.00 C | 3.60 C | 3.69 C |

## Limits
1. A good forecast does not prove real energy savings. The 8.63% saving is a simulation result; the real building never ran our optimizer.
2. On 2018 temperature the model is not better than persistence in MAE (0.352 against 0.319); it is better in RMSE (0.665 against 0.745). Report it as it is.
3. For power on normal working days the model equals the schedule baseline (0.406 kW). Most of its advantage over all days comes from the closure day.
4. 2019 test and 2018 were both seen during the analysis. Anything chosen after seeing them is a design change and must be documented. Use the reserved zones (Z1, Z2, Z5) once, after freezing the design, for a final claim.
5. The lunch rise varies by day (10th to 90th percentile 3.12 to 4.55 C in 2019) and with outdoor temperature. It is one scenario (65 minutes around noon). Matching its mean does not validate a thermal model for other shutdowns.
6. One zone of one building. The reserved-zone test (Z1, Z2, Z5) checks transfer between zones of the same building and period only; it would not show savings or transfer to other buildings. Its protocol is frozen in `docs/ZONE_TRANSFER_PROTOCOL.md`.
7. Reproducing these results (Level A) is separate from rebuilding the data from the raw files (Level B); see the README.

## Changes from v1
| Item | v1 | v2 |
|---|---|---|
| Gaps inside the lag window | allowed between the lags used (1,687 of 63,078 origins affected) | not allowed: rows t-12..t must all be measured |
| Lunch test | interpolated up to 2 missing rows | start and end rows must be measured, nothing interpolated |
| Split boundaries | 4 train and 4 validation targets crossed into the next split | origin and target must be in the same split |
| 2019 test, power MAE (model) | 0.343 (9,883 examples) | 0.396 (9,577) |
| 2019 test, temperature MAE (model) | 0.127 | 0.130 |
| 2018, temperature MAE (model / persistence) | 0.346 / 0.315 (13,784 examples) | 0.352 / 0.319 (8,940) |
| 2018, power MAE (model) | 2.013 | 2.104 |
| Lunch days 2019 / 2018 | 139 / 17 | 138 / 17 |
Package v2.1 (after a second review) changed no number: `check_reference.py` now checks checksums, settings, finite values and counts with a 1e-6 tolerance in the same environment; closure days are computed per zone by a fixed rule, and the Z4 closure dates are named as such; zone transfer uses the evaluated zone's own schedule baseline; the lunch figure is produced by `scripts/lunch_test.py`.

The conclusions did not change. The changes were made after seeing v1 results, because the review showed the code and the documents disagreed.
