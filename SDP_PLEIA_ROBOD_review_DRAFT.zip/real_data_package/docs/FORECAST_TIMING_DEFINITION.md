# Forecast experiment: timing definition, inputs and rules (reference version v2)

Scope: one forecasting experiment on CU-BEMS Zone 4: 2019 (train, validation, test) and a year-transfer check on summer 2018. It predicts **indoor temperature** and **total HVAC power** 15 minutes ahead. Reference code: `scripts/forecast_reference.py` (a simple gradient-boosting model; the team may replace the model and keep everything else). Frozen results and limits: `reference_run/` and `docs/REFERENCE_RESULTS.md`. Revision history: v1 (first version), v2 (after review: missing-data policy unified, split-boundary fix, zone-transfer reserved).

## 1. Definitions
- A row is a 5-minute interval. `timestamp` is its **start**; values are means over [timestamp, timestamp + 5 min).
- **Forecast origin T0 = end of row t** (= timestamp + 5 min). All rows up to and including t are available at T0.
- **Horizon 15 minutes:** the target is the **5-minute mean** (not an instantaneous reading) that starts at T0 + 15 min, i.e. **row t + 4** (`shift(-4)`).

| Step | Example |
|---|---|
| Row t (last row used) | 10:00 to 10:05 |
| Forecast origin T0 | 10:05 |
| Target row t + 4 | 10:20 to 10:25 |

- Targets: `indoor_temp_c` and `hvac_power_kw` (sum of the four AC channels).
- `check_alignment()` in the script tests this definition (and the weather rule below) on a small synthetic series every time it runs.

## 2. What may be used at T0
| Input | Allowed form |
|---|---|
| Indoor temperature, HVAC power, lighting, plug load | Rows up to t (current value and lags). Rows with `good_row = 0` stay missing; never fill them |
| Outdoor temperature and humidity | Last completed **hourly observation** at or before T0, taken from the rows on the original hourly grid (minute 0). The other 5-minute rows are interpolated and must not be used |
| Solar radiation | Mean of the last completed hour at T0, taken from the rows at minute 30 (the hourly means were centred and then interpolated) |
| Clock and calendar of the target time (time of day, Monday to Friday) | Allowed: known in advance |
| **Not allowed** | Any row after t, interpolated weather, `suggested_split`, `valid_minutes_of_5`, and the `good_row` of future rows as a model input |

Checked on the files: values at minute 0 have one decimal (humidity: whole numbers) and solar values at minute 30 are whole numbers, i.e. they are the original hourly values; the other rows are interpolated.

**Arrival-time assumption.** An hourly value is assumed to be available at its label time. Real readings may arrive later. As a sensitivity check, `--weather-lag-hours 1` delays weather and solar by one hour (in v1 this left temperature MAE at 0.13 C and moved power MAE from 0.34 to 0.39 kW).

### Missing-data policy (one rule set for code and documents)
1. Measured values are never filled, interpolated or smoothed. A row with `good_row = 0` is missing.
2. **Forecast examples:** all 13 rows from t - 12 to t must be measured (no gaps inside the window, not only at the lags used), and the target row must be measured. `good_row` of the target decides only whether the target exists when scoring.
3. **Lunch test:** the first row (11:50) and the last row (12:55) must be measured; nothing is interpolated; at least 85% of the window rows must be good.
4. **5-minute averages** use the minutes that exist, and a row is good only if at least 4 of its 5 minutes are valid.
5. **External weather and solar** are interpolated from hourly values by construction (disclosed). For forecasting only the last completed hourly value is used (section 2).
In v1 the forecast code required only the lag rows themselves (1,687 of 63,078 origins had a gap between them) and the lunch test interpolated up to 2 missing rows; both were corrected in v2.

## 3. Baselines (always report them)
- **Persistence:** the last observed value (row t).
- **Schedule:** the median value of the training period at the target's time of day, by day type (weekday or weekend).

## 4. Data split, the 2018 check and what is reserved
Train: to 31 Jul 2019. Validation: 1 Aug to 15 Sep 2019 (tuning and design decisions only). Test: 16 Sep to 22 Oct 2019. An example belongs to a split only if **both its origin row and its target row** are in it (rows whose target crosses a boundary are dropped).

**2018 is a year-transfer test, not an untouched test set.** Its reference results appear in this package and its behaviour was used in the analysis. It was never used for fitting. If the model is changed after seeing 2018 or 2019 test results, say so and report both versions.

**For a final claim, keep an evaluation set that was not used to choose any change.** Zones Z1, Z2 and Z5 (same building, same period, `data/CUBEMS_2019_Floor6_AllZones_real_long_5min.csv`) are reserved for this: the author of the reference code has **not** run any model on them. Use `--zone-transfer F6_Z5` (or Z1, Z2) once, after the design and the success criteria are frozen, following `docs/ZONE_TRANSFER_PROTOCOL.md`. This tests transfer between zones of the same building and period only. Zones differ in size and AC capacity, so expect larger power errors than on Z4.

## 5. What to report
MAE, RMSE and the number of examples for model, persistence and schedule, for each target and set. All three forecasts are scored on the **same examples**. Also: (a) errors near the switching times (target within 0 to 15 min after 07:45, 11:50, 13:00 or 16:25 on weekdays); (b) test results with and without the closure days (`data/weekday_ac_off_days.csv`; 14 Oct 2019 falls in the test period). Show the 2018 temperature result as it is: the model is not better than persistence there in MAE.

## 6. Success criteria (write them BEFORE looking at the reserved zones)
Example to fill in: "The model beats persistence and the schedule baseline on 2019 test and on 2018 for temperature; for power, it beats persistence and matches or beats the schedule." The team decides the wording and numbers. The reference model does **not** meet the temperature part of this example on 2018 (MAE), and for power on normal working days it only equals the schedule (section 8).

## 7. Later: acceptance test for any "what if we switch the AC off" model
Prediction accuracy alone does not prove such a model, and a good forecast does not prove real savings: the 8.63% saving remains a simulation result. The lunch shutdown is the only natural experiment in the data: the AC stops by timer at about 11:50 and restarts at 13:00, regardless of the room temperature. `scripts/lunch_test.py` selects the days and reports the rise in indoor temperature over the following 65 minutes (v2 policy):

| Year | Days | Mean rise | Spread (10th to 90th percentile) | First half of days | Second half |
|---|---|---|---|---|---|
| 2019 | 138 | 3.82 C | 3.12 to 4.55 C | 4.07 C | 3.56 C |
| 2018 | 17 | 3.65 C | 3.30 to 4.00 C | 3.60 C | 3.69 C |

The rise is not a constant. In 2019 it is larger when it is hotter outside (low, middle and high outdoor-temperature thirds: 3.48, 3.80 and 4.17 C) and differs between the first and the second half of the days. So an acceptance test should (a) predict each day from that day's own conditions and compare with the observed rise, not only the average; (b) fit on one set of days and test on others (for example the two chronological halves, or 2018); (c) report the share of days predicted within a tolerance chosen in advance. Matching the mean does not prove the model for other switch-off scenarios: this experiment covers one case (a 65-minute switch-off around noon, in warm weather, in one zone).

## 8. Reference results v2 (gradient boosting, `scripts/forecast_reference.py`)
| Set | Target | Examples | Model MAE / RMSE | Persistence MAE / RMSE | Schedule MAE / RMSE |
|---|---|---|---|---|---|
| 2019 validation | Temperature (°C) | 11,983 | 0.111 / 0.216 | 0.265 / 0.676 | 0.798 / 1.108 |
| 2019 validation | Power (kW) | 11,983 | 0.311 / 1.069 | 1.178 / 4.677 | 0.459 / 2.100 |
| 2019 test | Temperature (°C) | 9,577 | 0.130 / 0.255 | 0.258 / 0.663 | 0.965 / 1.323 |
| 2019 test | Power (kW) | 9,577 | 0.396 / 1.380 | 1.212 / 4.675 | 0.532 / 2.320 |
| 2019 test, without closure days | Temperature (°C) | 9,324 | 0.131 / 0.257 | 0.263 / 0.671 | 0.906 / 1.156 |
| 2019 test, without closure days | Power (kW) | 9,324 | 0.406 / 1.399 | 1.245 / 4.738 | 0.406 / 1.641 |
| 2018 year-transfer | Temperature (°C) | 8,940 | 0.352 / 0.665 | 0.319 / 0.745 | 1.170 / 1.521 |
| 2018 year-transfer | Power (kW) | 8,940 | 2.104 / 5.033 | 3.061 / 8.073 | 2.483 / 5.709 |

Reading:
- **Temperature:** the model adds value on 2019 (test MAE 0.130 against 0.258 for persistence). On 2018 its MAE (0.352) is **worse** than persistence (0.319), while its RMSE (0.665) is better than persistence (0.745), because persistence makes large errors at switching times. Do not say the model is better in every test.
- **Power:** much of the skill is the AC timer. On normal working days the model and the schedule baseline have the same MAE (0.406 kW). The model's advantage over all test days comes mainly from recognising the closure day.
- **2018 differs from 2019:** power while on about 10.8 kW against 17.3 kW; night temperature 26.9 C against 25.5 C. This hurts a model trained on absolute levels. The 2018 numbers use fewer examples (8,940) because the 2018 sensors have more gaps.
- Small differences are within run-to-run variation: changes of about 0.02 kW in power MAE appeared with tiny changes in the training rows.

## 9. Known issues
- The effect of using interpolated instead of last-completed-hour weather was small in v1 (test temperature MAE 0.125 against 0.127 C), but the rule in section 2 is the defensible one.
- `workday` is wrong on closure days (AC off on a weekday).
- All results come from one zone of one building.
