# ROBOD addition — private review draft

The five original ROBOD room datasets have been added separately under `data/ROBOD/`. The complete source materials from the supplied ROBOD archive are under `sources/ROBOD/`. See `docs/ROBOD_DATA_CARD.md` and `reference_run_robod/checksums_sha256.txt`. The source license remains unconfirmed: verify the official license before redistributing the ROBOD materials.

No data from different buildings have been merged, and no new model has been trained. This remains the earlier PLEIA integration draft, **not** the newer criteria-gated main package; its reserved-zone transfer is disabled. Earlier ROBOD analysis in the user-supplied note is reported but has not been independently reproduced.

---

# INTEGRATION DRAFT — PLEIAData added to the earlier v2.1 package

This is a **review copy**, not the latest main package. It is based on the previously provided `files_SDPb.zip`; the newer package with adopted-criteria validation was not available. Zone transfer is temporarily disabled in this draft, before data access, to keep Z1/Z2/Z5 reserved. Integrate the PLEIAData additions into the newer package when it is available; do not replace that package with this draft.

PLEIAData is kept as a separate real-building table. It contains no per-unit HVAC electrical meter or real occupant count. Its weather time-zone assignment and inferred motion states need further verification. Original measured temperature/CO2 were not interpolated; HVAC and motion states were propagated as described in the data card. The source and the CC BY 4.0 license, and the transformations, are documented in `docs/DATA_CARD_PLEIAData_12rooms.md`.

The submitted AC-stop test used a 70-minute interval while reporting 60 minutes. The copy here corrects it to 60 minutes, and the recalculated results are exploratory because the original results had already been seen. Original PLEIA raw inputs were not supplied, so raw-to-table rebuilding was not tested. Zone transfer was not run.

## PLEIAData files

- `data/PLEIAData_2021_12rooms_10min.csv`: derived 10-minute, 12-room table (630,720 rows).
- `docs/DATA_CARD_PLEIAData_12rooms.md`: source, license, transformations, limitations and corrected exploratory results.
- `scripts/build_pleia_rooms.py`: builder; requires the original raw archive (not included).
- `scripts/pleia_thermal_test.py`: exploratory analysis; requires scipy. From package root, run `cd data` then `python ../scripts/pleia_thermal_test.py`; it writes results to the current folder.
- `reference_run_pleia/`: corrected-event results from the integration run.

The reference checksum manifest was updated for the draft's disabled-zone guard and for the added files; the original manifest is preserved as `reference_run/checksums_sha256_original_before_pleia.txt`. The existing forecast and lunch-test results remain the same.

---

# Real-building data package (Smart Building Digital Twin)

Measured data from real buildings, prepared for the team. Not synthetic. Details, checks and limits are in `docs/`.

## Contents
| Path | What it is |
|---|---|
| `data/CUBEMS_2019_Floor6_Zone4_real_merged_5min.csv` | **Main file.** One zone, Bangkok, 6 Mar to 22 Oct 2019, every 5 min, with outdoor weather (66,226 rows) |
| `data/CUBEMS_2018_Floor6_Zone4_real_merged_5min.csv` | **Year-transfer test set** (different year, never used for fitting; its reference results have been seen). Same zone, 1 Jul to 14 Sep 2018 (21,888 rows) |
| `data/CUBEMS_2019_Floor6_AllZones_real_long_5min.csv` | Optional: zones Z1, Z2, Z4, Z5 stacked with `zone_id` |
| `data/FLEXLAB_2020_cellsAB_real_5min.csv` | Two small test cells, Berkeley, Jul to Aug 2020 (separate building) |
| `data/NTU_2018_2019_real_5min.csv` | Small office, Singapore, two control cases (separate building) |
| `data/weekday_ac_off_days.csv` | Monday-Friday days when the AC never ran (14 days): closure or holiday candidates, **not** an official holiday list |
| `data/real_operating_schedule_summary.csv`, `data/real_weekday_hourly_profile.csv` | The real AC timer schedule and hourly weekday profile (use as the baseline schedule) |
| `docs/DATA_CARD.md` | Sources, columns, checks, limits for the CU-BEMS files |
| `docs/DATA_CARD_FLEXLAB_NTU.md` | Same for FLEXLAB and NTU |
| `docs/ZONE_TRANSFER_PROTOCOL.md` | Frozen protocol for the reserved zones Z1, Z2, Z5 (read before running them) |
| `docs/REFERENCE_RESULTS.md`, `reference_run/` | Frozen reference results (v2), limits, changes from v1, environment and checksums |
| `scripts/check_reference.py` | Re-runs the reference forecast and lunch test and compares with `reference_run/` |
| `docs/FORECAST_TIMING_DEFINITION.md` | Timing definition, allowed inputs, baselines, split and reporting rules for the forecast experiment, with reference results |
| `scripts/forecast_reference.py` | Reference implementation of that experiment (model vs persistence vs schedule); 2018 is evaluated only with `--final` |
| `scripts/lunch_test.py` | Lunch-shutdown natural experiment: day selection, the distribution of the temperature rise (2019 and 2018) and the comparison figure |
| `scripts/build_real_data.py` | Rebuilds the three CU-BEMS files from the raw figshare files, offline (see below) |
| `scripts/fetch_external.py` | Downloads the weather and solar inputs (needs internet) |
| `external/` | The weather (Meteostat) and solar (Open-Meteo) inputs actually used |
| `figures/` | Overview, lunch-shutdown test, simulator vs real |

## Load it
```python
import pandas as pd
df = pd.read_csv("data/CUBEMS_2019_Floor6_Zone4_real_merged_5min.csv", parse_dates=["timestamp"])
df = df[df.good_row == 1]            # use only good rows for fitting and scoring
train = df[df.suggested_split == "train"]
```

## Rules
- Use `good_row == 1`. Do not fill or interpolate missing measured values.
- Rows are exactly 5 minutes apart. If you build lags, require **every** row in the lag window to be measured (no gaps inside the window, not only at the lags used); the reference code does this.
- Use `suggested_split` (time-based); never shuffle rows between train and test. The 2018 file is a year-transfer test only; read `docs/FORECAST_TIMING_DEFINITION.md` first.
- Do not mix buildings in one table by default. If you combine real and synthetic data (or several buildings) for training, add `building_id` and `data_origin` columns and evaluate on real data only.
- Never report simulator (synthetic) results as real-building results.

## Main findings so far
- The real AC runs on a timer: 07:45 to 11:50 and 13:00 to 16:25 on working weekdays (within about 5 minutes); about 21 to 22 C while on; off at night and on weekends.
- Lunch test: after the AC stops, the real room warms about 3.8 C in 65 min on average (138 days in 2019, 10th to 90th percentile 3.1 to 4.6 C; 3.65 C on 17 days in 2018); our simulator equation predicts about 1 C. The rise is not constant: it grows with outdoor temperature.
- Reference forecast (15 min ahead, v2): temperature MAE 0.130 C against 0.258 C for persistence on the 2019 test period; on 2018 the model is **not** better than persistence in MAE (0.352 against 0.319 C). After excluding specified closure dates, power MAE is about 0.406 kW for the model and schedule; this subset still includes weekends. A good forecast does not prove real savings; the 8.63% saving remains a simulation result.
- Simulator reported numbers reproduce (5.90% dev week, 8.63% test week), but they come from a baseline that differs from the real one.

## Not in the data
No occupancy count, setpoint or CO2 in CU-BEMS; solar radiation is modeled (reanalysis), not measured. The CU-BEMS zone is much larger than the simulated 120 m2 office, so compare shapes and behavior, not absolute kW. The real building never ran our optimizer, so real-world savings cannot be claimed.

## Credit and licences
CU-BEMS (Chulalongkorn University): https://doi.org/10.1038/s41597-020-00582-3 (data licence: CC BY 4.0, figshare record version 4). Weather: Meteostat, station 48455 (CC BY-NC 4.0). Solar radiation: Open-Meteo.com Historical Weather API (ERA5 reanalysis), CC BY 4.0 with attribution (check terms on open-meteo.com). FLEXLAB and NTU: IEA EBC Annex 81 dataset, CC BY 4.0, https://data.mendeley.com/datasets/xztfbtsgys/3

## Citation (CU-BEMS)

Pipattanasomporn, Manisa; Chitalia, Gopal; Songsiri, Jitkomut; Aswakul, Chaodit; Pora, Wanchalerm; Suwankawin, Surapong; et al. (2020). CUBEMS, a smart building electricity consumption and indoor environmental sensor dataset. figshare. Dataset. https://doi.org/10.6084/m9.figshare.11726517.v4

Licence: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)

## Two separate checks (do not confuse them)
| Level | What it shows | Needs | Command |
|---|---|---|---|
| **A. Results** | The forecast and the lunch-test numbers can be reproduced from the packaged data (checksums, settings, finite numbers, counts; errors within 1e-6 in the same environment) | Packaged files only (pandas, numpy, scikit-learn) | `python scripts/check_reference.py` (and `--selftest` tests the comparison itself) |
| **B. Data** | The packaged CU-BEMS files can be rebuilt from the raw figshare files | The raw files (not in the package) | `python scripts/build_real_data.py ... --verify data` (below) |
Level A does not prove Level B and the other way round. The FLEXLAB and NTU files are not rebuilt by any script (they come from the Mendeley files with the steps in `docs/DATA_CARD_FLEXLAB_NTU.md`).

## Rebuild from raw (reproducibility, Level B)
1. Download `2018Floor6.csv` and `2019Floor6.csv` from https://doi.org/10.6084/m9.figshare.11726517 into one folder. Expected MD5: `2019Floor6.csv` 4f2446b38b566f2c1a07bf0e44587b42 (matches the figshare record); `2018Floor6.csv` e4074802fd7973a87e620a9ea1a381b6 (our copy, not compared with the record).
2. From this package folder (needs Python with pandas and numpy):
```
python scripts/build_real_data.py --raw-dir C:\path\to\raw --external-dir external --out-dir rebuilt --verify data
```
3. The script prints rows and good rows for each file and `PASS` when the rebuilt file equals the one in `data/` (it is byte-identical).
`scripts/fetch_external.py` refreshes the weather and solar inputs from the internet (needs `pip install meteostat`); providers may change values, so the copies in `external/` are the reference. That script reuses the code run in our notebook but was not re-run when the package was assembled.

## Run the reference forecast
```
python scripts/forecast_reference.py --data-dir data --out-dir results            # train, validation and test 2019
python scripts/forecast_reference.py --data-dir data --out-dir results --final    # also 2018 (year-transfer check)
# Zone transfer is disabled in this draft; use the newer criteria-gated package.
python scripts/check_reference.py                                                   # compare with the frozen reference run
```
```
python scripts/lunch_test.py --data-dir data --out-dir results                  # lunch-shutdown experiment (needs pandas, numpy)
```
The forecast script needs pandas, numpy and scikit-learn (matplotlib optional for the figure); it checks its own timing definition on every run. Read `docs/FORECAST_TIMING_DEFINITION.md` first.
